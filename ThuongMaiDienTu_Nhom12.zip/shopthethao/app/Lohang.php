<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Lohang extends Model
{
    protected $table = "lohang";
    protected $fillable = [
        'id','so_luong_nhap','so_luong_da_ban','so_luong_dat_hang','so_luong_doi_tra','so_luong_giao_hang','so_luong_hien_tai','nhacungcap_id','sanpham_id','tinh_trang'
    ];
	public $timestamps = true;

    public static function findAll() {
        $lohangQuery = DB::table('lohang')
        ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
        ->select('lohang.*','sanpham.ten');
        return $lohangQuery;
    }

    public static function findAllByProduct($id) {
        $lohangQuery = DB::table('lohang')
                            ->where('sanpham_id','=',$id)
                            ->select('lohang.*');
        return $lohangQuery;
    }

    public static function findOne($id) {
        $lohangQuery = DB::table('lohang')
                    ->where('id','=',$id)
                    ->first();
        return $lohangQuery;
    }

    public static function findOneByProduct($id) {
        $lohangQuery = DB::table('lohang')
                    ->where('sanpham_id','=',$id)
                    ->first();
        return $lohangQuery;
    }

    public static function getNumberOfProduct($id) {
        $lohangQuery = DB::table('lohang')
                    ->where('sanpham_id','=',$id)
                    ->select(DB::raw('so_luong_hien_tai as so_luong'),DB::raw('so_luong_dat_hang as so_luong_dat_hang'))
                    ->groupBy('sanpham_id')
                    ->first();
        if(is_null($lohangQuery)){
            return 0;
        }
        return $lohangQuery->so_luong - $lohangQuery->so_luong_dat_hang;
    }

    public static function findFirstOneByProduct($id) {
        $lohangQuery = DB::table('lohang')
                    ->where('sanpham_id','=',$id);
        return $lohangQuery;
    }

    public static function findImport() {
        $import = DB::table('lohang')
    		->join('sanpham','sanpham.id','=','lohang.sanpham_id')
            ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
            ->select('lohang.*',DB::raw('sanpham.ten as ten_sanpham'), DB::raw('loaisanpham.ten as ten_loaisanpham'))
            ->where(DB::raw('sanpham.user_id'))
	    	->get();
        return $import;
    }

    public static function findSale() {
        $sale = DB::table('lohang')
                ->where('lohang.so_luong_da_ban','>',0)
                ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
                ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
                ->select('lohang.*',DB::raw('sanpham.ten as ten_sanpham'), DB::raw('loaisanpham.ten as ten_loaisanpham'))
                ->where(DB::raw('sanpham.user_id'))
                ->get();
        return $sale;
    }

    public static function findAvailable() {
        $available = DB::table('lohang')
                    ->where('lohang.so_luong_hien_tai','>',0)
                    ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
                    ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
                    ->select('lohang.*',DB::raw('sanpham.ten as ten_sanpham'), DB::raw('loaisanpham.ten as ten_loaisanpham'))
                    ->where(DB::raw('sanpham.user_id'))
                    ->get();
        return $available;
    }

    public static function findReturn() {
        $return = DB::table('lohang')
                ->where('lohang.so_luong_doi_tra','>',0)
                ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
                ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
                ->select('lohang.*',DB::raw('sanpham.ten as ten_sanpham'), DB::raw('loaisanpham.ten as ten_loaisanpham'))
                ->where(DB::raw('sanpham.user_id'))
                ->get();
        return $return;
    }

    public static function findHotSale() {
        $hotSale = DB::table('lohang')
                    ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
                    ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
                    ->select(
                                'lohang.id','sanpham_id','sanpham.gia',
                                DB::raw('sanpham.ten as ten_sanpham'),
                                DB::raw('loaisanpham.ten as ten_loaisanpham'),
                                DB::raw('so_luong_nhap as nhap'),
                                DB::raw('so_luong_da_ban as ban'),
                                DB::raw('so_luong_hien_tai as ton')
                            )
                    ->where(DB::raw('sanpham.user_id'))
                    ->groupBy('sanpham_id')
                    ->orderBy('so_luong_da_ban', 'desc')
                    ->get();
        return $hotSale;
    }

    public static function findHotImport() {
        return DB::table('lohang')
                    ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
                    ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
                    ->select('lohang.id','sanpham_id', 'sanpham.ten', DB::raw('loaisanpham.ten as ten_loaisanpham'), DB::raw('so_luong_nhap as nhap'), DB::raw('sanpham.ten as ten_sanpham'))
                    ->where(DB::raw('sanpham.user_id'))
                    ->groupBy('sanpham_id')
                    ->orderBy('so_luong_nhap', 'desc')
                    ->take(10)
                    ->get();
    }

    public static function findInactiveStock() {
        $inactiveStock = DB::table('lohang')
                    ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
                    ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
                    ->select (
                                'sanpham_id',
                                'lohang.id',
                                DB::raw('loaisanpham.ten as ten_loaisanpham'),
                                DB::raw('so_luong_nhap as nhap'),
                                DB::raw('so_luong_da_ban as ban'),
                                DB::raw('so_luong_hien_tai as ton'), 
                                DB::raw('sanpham.ten as ten_sanpham')
                            )
                    ->where(DB::raw('sanpham.user_id'))
                    ->groupBy('sanpham_id')
                    ->orderBy('so_luong_hien_tai', 'desc')
                    ->get();
        return $inactiveStock;
    }

    public static function findStock() {
        $stock = DB::table('lohang')
             ->join('sanpham','sanpham.id','=','lohang.sanpham_id')
             ->join('loaisanpham','loaisanpham.id','=','sanpham.loaisanpham_id')
	    	->select (
                        DB::raw('loaisanpham.ten as ten_loaisanpham'),
                        DB::raw('so_luong_nhap as nhap'),
                        DB::raw('so_luong_da_ban as ban'),
                        DB::raw('so_luong_hien_tai as ton'),
                        DB::raw('so_luong_doi_tra as tra')
                     )
                     ->where(DB::raw('sanpham.user_id'))
	    	->get();
        return $stock;
    }

    public static function add($quantity,$product) {
        $lohang = new Lohang;
        $lohang->so_luong_nhap = $quantity;
        $lohang->so_luong_da_ban = 0;
        $lohang->so_luong_giao_hang = 0;
        $lohang->so_luong_doi_tra = 0;
        $lohang->so_luong_hien_tai = $quantity;
        $lohang->sanpham_id = $product;
        $lohang->save();
    }

    public static function edit($id,$quantity,$product) {
        $lohang = Lohang::findOne($id);
    	DB::table('lohang')->where('id',$id)
            ->update([
                'so_luong_nhap' => $quantity,
                'so_luong_hien_tai' => ($quantity - $lohang->so_luong_da_ban),
                'sanpham_id' => $product
            ]);
    }

    public static function deliver($id,$noSell) {
        $lohang = Lohang::findOneByProduct($id);
        DB::table('lohang')
                ->where('id',$lohang->id)
                ->update([
                    'so_luong_giao_hang' => $lohang->so_luong_giao_hang + $noSell,
                    'so_luong_hien_tai' => $lohang->so_luong_hien_tai - $noSell
                    ]);
    }

    public static function cancel($id,$noSell) {
        $lohang = Lohang::findOneByProduct($id);
        if(!is_null($lohang)) {
            DB::table('lohang')
                ->where('id',$lohang->id)
                ->update([
                        'so_luong_doi_tra' => $lohang->so_luong_doi_tra + $noSell,
                        'so_luong_giao_hang' => $lohang->so_luong_giao_hang - $noSell,
                        'so_luong_hien_tai' => $lohang->so_luong_hien_tai + $noSell,
                        'so_luong_dat_hang' => $lohang->so_luong_dat_hang - $noSell,
                    ]);
        }
    }

    public static function cancel1($id,$noSell) {
        $lohang = Lohang::findOneByProduct($id);
        if(!is_null($lohang)) {
            DB::table('lohang')
                ->where('id',$lohang->id)
                ->update([
                        'so_luong_doi_tra' => $lohang->so_luong_doi_tra + $noSell,
                        'so_luong_giao_hang' => $lohang->so_luong_giao_hang - $noSell,
                        'so_luong_hien_tai' => $lohang->so_luong_hien_tai + $noSell,
                    ]);
        }
    }

    public static function sell($id,$noSell) {
		$lohang = Lohang::findOneByProduct($id);
        DB::table('lohang')
                ->where('id',$lohang->id)
                ->update([
                    'so_luong_giao_hang' => $lohang->so_luong_giao_hang - $noSell,
                    'so_luong_da_ban' => $lohang->so_luong_da_ban + $noSell,
                    'so_luong_dat_hang' => $lohang->so_luong_dat_hang - $noSell,
                    ]);
    }


    public static function remove($id) {
        DB::table('lohang')->where('id','=',$id)->delete();
    }

}
