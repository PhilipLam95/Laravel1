<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Quangcao extends Model {
    protected $table="quangcao";
    protected $fillable = ['anh','trang_thai'];
	public $timestamps = true;

    public static function findAll() {
        $advertisements = DB::table('quangcao');
        return $advertisements;
    }

    public static function findAllAccepted() {
        $advertisements = DB::table('quangcao')->where('trang_thai',1);
        return $advertisements;
    }

    public static function findAllUnaccepted() {
        $advertisements = DB::table('quangcao')->where('trang_thai',0);
        return $advertisements;
    }

    public static function findOne($id) {
        $advertisement = DB::table('quangcao')
        ->where('id','=',$id)
        ->first();
        return $advertisement;
    }
    public static function add($name,$status,$product,$description) {
        $advertisement = new Quangcao;
        $advertisement->ten = $name;
        $advertisement->trang_thai = $status;
        $advertisement->sanpham_id = $product;
        $advertisement->noi_dung = $description;
    	$advertisement->save();
        return $advertisement->id;
    }

    public static function addImage($id,$imageName) {
            DB::table('quangcao')->where('id',$id)
                            ->update([
                                'anh'   => $imageName
                                ]);
    }

    public static function edit($id,$name,$status,$description) {
            DB::table('quangcao')->where('id',$id)
                            ->update([
                                'ten'   => $name,
                                'trang_thai' => $status,
                                'noi_dung' => $description,
                                ]);
    }

    public static function hide($id) {
        DB::table('quangcao')->where('id',$id)
                            ->update([
                                'trang_thai'   => 0
                                ]);
    }

    public static function show($id) {
        DB::table('quangcao')->where('id',$id)
                            ->update([
                                'trang_thai'   => 1
                                ]);
    }


    public static function remove($id) {
        DB::table('quangcao')->where('id','=',$id)->delete();
    }
}
