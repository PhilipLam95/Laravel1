<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Nhacungcap extends Model
{
    protected $table = "nhacungcap";
    protected $fillable = ['ten','dia_chi','sdt'];
	public $timestamps = true;
    
    public static function findAll() {
        $vendor = DB::table('nhacungcap');
        return $vendor;
    }

    public static function findOne($id) {
        $vendor = DB::table('nhacungcap')
        ->where('id','=',$id)
        ->first();
        return $vendor;
    }

    public static function add($name,$phone,$address) {
        $vendor = new Nhacungcap;
        $vendor->ten = $name;
        $vendor->dia_chi = $address;
        $vendor->sdt = $phone;
        $vendor->save();
    }


    public static function edit($id,$name,$phone,$address) {
        DB::table('nhacungcap')
                    ->where('id',$id)->update(['ten'=> $name,'dia_chi' => $address,'sdt' => $phone]);
    }

    public static function remove($id) {
        DB::table('nhacungcap')->where('id','=',$id)->delete();
    }

}
