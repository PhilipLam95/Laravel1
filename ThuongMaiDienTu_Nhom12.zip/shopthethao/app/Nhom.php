<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Nhom extends Model {
    protected $table="nhom";
    protected $fillable = ['ten','mo_ta','url','anh'];
	public $timestamps = true;

    public static function findAll() {
        $sanPhamsQuery = DB::table('nhom');
        return $sanPhamsQuery;
    }

    public static function findOne($id) {
        $sanPhamsQuery = DB::table('nhom')->where('id','=',$id)->first();
        return $sanPhamsQuery;
    }

    public static function findAllWithGroup() {
        $loaiSanPhamQuery = DB::table('loaisanpham')
            ->leftJoin('nhom','loaisanpham.nhom_id', '=', 'nhom.id')
            ->select('loaisanpham.*','nhom.ten as ten_nhom')
            ->orderBy('nhom.id');
        return $loaiSanPhamQuery;
    }


    public static function add($name) {
        $group = new Nhom;
        $group->ten   = $name;
    	$group->save();
    }


    public static function edit($id,$name) {
            DB::table('nhom')->where('id',$id)
                            ->update(['ten'   => $name]);
    }

    public static function remove($id) {
        DB::table('nhom')->where('id','=',$id)->delete();
    }

}
