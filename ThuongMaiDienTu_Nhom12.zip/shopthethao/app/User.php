<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;

class User extends Authenticatable{

    protected $fillable = [
        'email', 'password','ten','so_tai_khoan','sdt','dia_chi','loai_tai_khoan','anh','trang_thai','verifytoken'
    ];
    protected $hidden = [
        'password', 'remember_token',
    ];

    public static function findAll() {
        $users = DB::table('users');
        return $users;
    }

    public static function findAllCustomers() {
        $users = DB::table('users')->where('loai_tai_khoan','=','Khách hàng');
        return $users;
    }

    public static function countCustomers() {
        return DB::table('users')
        ->where('loai_tai_khoan','=','Khách hàng')
        ->count();
    }

    public static function findAllPartners() {
        $users = DB::table('users')->where('loai_tai_khoan','=','Đối tác');
        return $users;
    }

    public static function findAllEmployees() {
        $users = DB::table('users')
        ->where('loai_tai_khoan','=','Nhân viên')
        ->orWhere('loai_tai_khoan','=','Admin');
        return $users;
    }

    public static function findAllAdmins() {
        $users = DB::table('users')->where('loai_tai_khoan','=','admin');
        return $users;
    }

    public static function findOne($id) {
        $users = DB::table('users')
        ->where('id','=',$id)
        ->first();
        return $users;
    }

    public static function findOneByEmail($email) {
        $users = DB::table('users')
        ->where('email','=',$email)
        ->first();
        return $users;
    }

    public static function findOneCustomer($id) {
        $users = DB::table('users')
        ->where('loai_tai_khoan','=','Nhân viên')
        ->where('id','=',$id)
        ->first();
        return $users;
    }

    public static function findOneEmployee($id) {
        $users = DB::table('users')
        ->where('loai_tai_khoan','=','nhân viên')
        ->where('id','=',$id)->first();
        return $users;
    }

    public static function findOneAdmin($id) {
        $users = DB::table('users')
        ->where('loai_tai_khoan','=','admin')
        ->where('id','=',$id)->first();
        return $users;
    }

    public static function edit($id,$name,$email,$password,$bankId,$phone,$address) {
        DB::table('users')->where('id',$id)
                        ->update([
                                'ten' => $name,
                                'email' => $email,
                                'password' => bcrypt($password),
                                'so_tai_khoan' => $bankId,
                                'sdt' => $phone,
                                'dia_chi' => $address,
                            ]);
    }

    public static function editNoPass($id,$name,$email,$bankId,$phone,$address) {
        DB::table('users')->where('id',$id)
                        ->update([
                                'ten' => $name,
                                'email' => $email,
                                'so_tai_khoan' => $bankId,
                                'sdt' => $phone,
                                'dia_chi' => $address,
                            ]);
    }

    public static function add($name,$email,$phone,$role,$address,$bankId) {
        $user = User::create([
            'ten' => $name,
            'email' => $email,
            'password' => bcrypt('123'),
            'sdt' => $phone,
            'dia_chi' => $address,
            'so_tai_khoan' => $bankId,
            'loai_tai_khoan' => $role,
            'trang_thai' => 'Hoạt động'
        ]);
    }

    public static function updateRole($id,$role) {
        DB::table('users')->where('id',$id)
            ->update(['loai_tai_khoan' => $role]);
    }

    public static function updateStatus($id,$status) {
        DB::table('users')->where('id',$id)
            ->update(['trang_thai' => $status]);
    }

    public static function updateToken($id,$token) {
        DB::table('users')->where('id',$id)
            ->update(['verifytoken' => $token]);
    }

    public static function signup($name,$email,$phone,$address,$password,$bankId) {
        try{
            $user = User::create([
                'ten' => $name,
                'email' => $email,
                'password' => bcrypt($password),
                'sdt' => $phone,
                'dia_chi' => $address,
                'so_tai_khoan' => $bankId,
                'loai_tai_khoan' => 'Khách hàng',
                'trang_thai' => 'Hoạt động'
            ]); 
        } catch (\Exception $e) {
            return null;
        }
        return $user;
    }

    public static function addImage($id,$imageName) {
        try{
            DB::table('users')->where('id',$id)
                            ->update([
                                'anh'   => $imageName
                                ]);
        } catch (\Exception $e) {
            return null;
        }
    }

    public static function remove($id) {
        try{
            DB::table('users')->where('id','=',$id)->delete();
        } catch (\Exception $e) {
            return null;
        }
    }

}
