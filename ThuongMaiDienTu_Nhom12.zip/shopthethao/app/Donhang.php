<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Donhang extends Model
{
    protected $table = "donhang";
    protected $fillable = [
        'id','nguoi_nhan','email','sdt','dia_chi','ghi_chu','tong_tien','khachhang_id','tinh_trang','delivered_at'
    ];
	public $timestamps = true;

    public static function findAll() {
        $orders = DB::table('donhang')
                        ->join('users','donhang.khachhang_id','=','users.id')
                        ->select('donhang.*',DB::raw('users.ten as ten_khachhang'));
        return $orders;
    }

    public static function findAllDelivery() {
        $comments = DB::table('donhang')
                    ->where('tinh_trang','Đang xử lý')
                    ->orWhere('tinh_trang','Đã xác nhận')
                    ->orWhere('tinh_trang','Đang giao hàng')
                    ->join('users','donhang.khachhang_id','=','users.id')
                    ->select('donhang.*',DB::raw('users.ten as ten_khachhang'));
        return $comments;
    }

    public static function findAllUnaccepted() {
        $comments = DB::table('donhang')
                    ->where('tinh_trang','Chưa xác nhận')
                    ->join('users','donhang.khachhang_id','=','users.id')
                    ->select('donhang.*',DB::raw('users.ten as ten_khachhang'));
        return $comments;
    }

    public static function findAllByPartner($id) {
        $orders = DB::table('donhang')
                        ->join('users','donhang.khachhang_id','=','users.id')
                        ->join('chitietdonhang','donhang.id','=','chitietdonhang.donhang_id')
                        ->join('sanpham','sanpham.id','=','chitietdonhang.sanpham_id')
                        ->select('donhang.*',DB::raw('users.ten as ten_khachhang'))
                        ->where('sanpham.user_id','=',$id);
        return $orders;
    }

    public static function findAllOfCustomer($id) {
        $orders = DB::table('donhang')
                        ->where('donhang.khachhang_id','=',$id);
        return $orders;
    }

    public static function findOne($id) {
        $order = DB::table('donhang')->where('donhang.id','=',$id)->first();
        return $order;
    }


    public static function findOneWithDetail($id) {
        $order = DB::table('donhang')
        ->join('chitietdonhang','donhang.id','=','chitietdonhang.donhang_id')
        ->join('sanpham','sanpham.id','=','chitietdonhang.sanpham_id')
        ->where('donhang.id','=',$id);
        return $order;
    }

    public static function findHistoryOfCustomer($id) {
        $purchaseHistory = DB::table('donhang')
        ->join('users','donhang.khachhang_id','=','users.id')
        ->join('chitietdonhang','donhang.id','=','chitietdonhang.donhang_id')
        ->join('sanpham','sanpham.id','=','chitietdonhang.sanpham_id')
        ->select(DB::raw('users.id as user_id'),'donhang.*')
        ->distinct()
        ->where('users.id','=',$id);
        return $purchaseHistory;
    }
        
     public static function find10HotSale() {
        $orders =DB::table('donhang')
                ->where('donhang.tinh_trang','Đã thanh toán')
                ->join('users','users.id','=','donhang.khachhang_id')
                ->select('khachhang_id', 'users.ten', DB::raw('COUNT(khachhang_id) as so_don_hang'), DB::raw('SUM(tong_tien) as tien'))
                ->groupBy('khachhang_id')
                ->orderBy('tien', 'desc')
                ->take(10)
                ->get();
        return $orders;
    }

    public static function countUnapprove() {
        return DB::table('donhang')->where('tinh_trang','=','Chưa xác nhận')->count();
    }

    public static function add($id,$name,$phone,$email,$address,$note,$total,$token) {
        $order = new Donhang;
        $order->nguoi_nhan = $name;
        $order->email = $email;
        $order->sdt = $phone;
        $order->dia_chi = $address;
        $order->ghi_chu = $note;
        $order->tong_tien = $total;
        $order->khachhang_id = $id;
        $order->token = $token;
        $order->tinh_trang = 'Chưa xác nhận';
        $order->save();
        return $order->id;
    }

    public static function edit($id,$name,$phone,$email,$address,$note) {
        DB::table('donhang')->where('id',$id)
    		->update([
    			'nguoi_nhan'=> $name,
    			'sdt'=> $phone,
    			'email'=> $email,
    			'dia_chi'=> $address,
    			'ghi_chu'=> $note,
    		]);
    }

    public static function updateStatus($id,$status) {
        DB::table('donhang')->where('id',$id)
            ->update(['tinh_trang' => $status]);
    }

    public static function setDeliverTime($id) {
        $time = $order = DB::table('donhang')->where('donhang.id','=',$id)->first()->updated_at;
        DB::table('donhang')->where('id',$id)
            ->update(['delivered_at' => $time]);
    }

    public static function updateToken($id,$token) {
        DB::table('donhang')->where('id',$id)
            ->update(['token' => $token]);
    }

    public static function updateSum($id,$sum) {
        DB::table('donhang')->where('id',$id)
            ->update(['tong_tien' => $sum]);
    }


    public static function remove($id) {
        DB::table('donhang')->where('id','=',$id)->delete();
    }

}
