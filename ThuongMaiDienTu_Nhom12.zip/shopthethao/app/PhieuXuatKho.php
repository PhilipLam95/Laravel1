<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class PhieuXuatKho extends Model{
    protected $table="phieuxuatkho";
    protected $fillable = ['so_luong','trang_thai'];
	public $timestamps = true;

    public static function findAllByOrder($id) {
        $phieu = DB::table('phieuxuatkho')->where('donhang_id','=',$id)->where('trang_thai','=',1);
        return $phieu;
    }

    public static function add($number,$lohang,$order) {
        $phieu = new PhieuXuatKho;
        $phieu->so_luong = $number;
        $phieu->lohang_id = $lohang;
        $phieu->donhang_id = $order;
        $phieu->trang_thai = 1;
    	$phieu->save();
    }

    public static function findAllByInvoiceID($id) {
        $orderDetailQuery = DB::table('phieuxuatkho')->where('donhang_id','=',$id);
        return $orderDetailQuery;
    }


    public static function cancel($id) {
        DB::table('phieuxuatkho')->where('id',$id)
                            ->update([
                                'trang_thai'   => 0
                                ]);
    }

    public static function removeByOrder($id) {
        DB::table('phieuxuatkho')->where('donhang_id','=',$id)->delete();
    }
}
