<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\softDeletes;
use DB;

class Sanpham extends Model {
    use SoftDeletes;
    protected $table = "sanpham";
    protected $fillable = ['id','ten','anh_0','gia','mo_ta','luot_xem','loaisanpham_id','user_id'];
	public $timestamps = true;
    protected $dates = ['deleted_at'];

    public static function findAll() {
        $sanPhamsQuery = DB::table('sanpham');
        return $sanPhamsQuery;
    }

    public static function findAllOfPartner($id) {
        $sanPhamsQuery = DB::table('sanpham')->where('sanpham.user_id',$id);;
        return $sanPhamsQuery;
    }

    public static function findAllWithCate() {
        $sanPhamsQuery = DB::table('sanpham')
                            ->join('loaisanpham','sanpham.loaisanpham_id','=','loaisanpham.id')
                            ->select('sanpham.*',DB::raw('loaisanpham.ten as ten_loaisanpham'));
        return $sanPhamsQuery;
    }

    public static function findAllWithCateOfPartner($id) {
        $sanPhamsQuery = DB::table('sanpham')
                            ->join('loaisanpham','sanpham.loaisanpham_id','=','loaisanpham.id')
                            ->select('sanpham.*',DB::raw('loaisanpham.ten as ten_loaisanpham'))
                            ->where('sanpham.user_id',$id);
        return $sanPhamsQuery;
    }

    public static function findAllWithCateOnlyTrashed() {
        $sanPhamsQuery = Sanpham::onlyTrashed()
                            ->join('loaisanpham','sanpham.loaisanpham_id','=','loaisanpham.id')
                            ->select('sanpham.*',DB::raw('loaisanpham.ten as ten_loaisanpham'));
        return $sanPhamsQuery;
    }

    public static function findAllLikeKeyword($keyword) {
        $sanPhamsQuery = DB::table('sanpham')
            ->where('sanpham.ten','like','%'.$keyword.'%')
            ->leftJoin('khuyenmai',function($query) {
                $query->on('sanpham.id','=','khuyenmai.sanpham_id')
                      ->where('khuyenmai.ngay_ket_thuc','>=', date('Y-m-d'));
            })
            ->leftJoin('lohang','sanpham.id', '=', 'lohang.sanpham_id')
            // ->where('lohang.so_luong_hien_tai','>',0)
            // ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id','sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('sum(lohang.so_luong_hien_tai) as so_luong'),'sanpham.user_id')
            ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id','sanpham.ten','sanpham.anh_0',DB::raw('sanpham.loaisanpham_id as loaisanpham_id'),'lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('lohang.so_luong_hien_tai as so_luong'),DB::raw('lohang.so_luong_dat_hang as so_luong_dat_hang'),'sanpham.user_id')
            ->groupBy('sanpham.id')
            ->orderBy('sanpham.ten','ASC');
        return $sanPhamsQuery;
    }

    public static function count() {
        $sanPhamsQuery = DB::table('sanpham')->count();
        return $sanPhamsQuery;
    }

    public static function findOne($id) {
        $sanPhamsQuery = DB::table('sanpham')->where('id','=',$id)->first();
        return $sanPhamsQuery;
    }

    public static function findOneIdByName($name) {
        $sanPham = DB::table('sanpham')->where('name','like',$name)->first();
        return $sanPham->id;
    }

    public static function findAllByName($name) {
        $sanPham = DB::table('sanpham')->where('name','like',$name);
        return $sanPham;
    }

    public static function findAllWithPromotion() {
        $sanPhamsQuery = DB::table('sanpham')            
            ->leftJoin('khuyenmai',function($query) {
                $query->on('sanpham.id','=','khuyenmai.sanpham_id')
                      ->where('khuyenmai.ngay_ket_thuc','>=', date("Y-m-d"));
            })
            ->leftJoin('lohang','sanpham.id', '=', 'lohang.sanpham_id')
            // ->where('lohang.so_luong_hien_tai','>',0)
            // ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id','sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('sum(lohang.so_luong_hien_tai) as so_luong'),'sanpham.user_id')
            ->select('sanpham.id','sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('lohang.so_luong_hien_tai as so_luong'),DB::raw('lohang.so_luong_dat_hang as so_luong_dat_hang'),'sanpham.user_id')
            ->groupBy('lohang.so_luong_hien_tai','lohang.id')
            ->orderBy('lohang.id','DESC');
        return $sanPhamsQuery;
    }

    public static function findOneWithPromotion($id) {
        $sanPhamsQuery = DB::table('sanpham')            
            ->leftJoin('khuyenmai',function($query) {
                $query->on('sanpham.id','=','khuyenmai.sanpham_id')
                      ->where('khuyenmai.ngay_ket_thuc','>=', date('Y-m-d'));
            })
            ->leftJoin('lohang','sanpham.id', '=', 'lohang.sanpham_id')
            ->where('sanpham.id','=',$id)
            // ->where('lohang.so_luong_hien_tai','>',0)    
            // ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id','sanpham.ten','sanpham.mo_ta','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('sum(lohang.so_luong_hien_tai) as so_luong'),'sanpham.user_id')
            ->select('sanpham.id','sanpham.ten','sanpham.mo_ta','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('lohang.so_luong_hien_tai as so_luong'),DB::raw('lohang.so_luong_dat_hang as so_luong_dat_hang'),DB::raw('sanpham.loaisanpham_id as loaisanpham_id'),'sanpham.user_id')
            ->first();
        return $sanPhamsQuery;
    }

    public static function findAllWithPromotionInGroup($id) {
        $sanPhamsQuery = DB::table('sanpham')     
            ->join('loaisanpham','loaisanpham.id', '=', 'sanpham.loaisanpham_id')       
            ->leftJoin('khuyenmai',function($query) {
                $query->on('sanpham.id','=','khuyenmai.sanpham_id')
                      ->where('khuyenmai.ngay_ket_thuc','>=', date('Y-m-d'));
            })
            ->join('lohang','sanpham.id', '=', 'lohang.sanpham_id')
            ->join('nhom','nhom.id','=','loaisanpham.nhom_id')
            ->where('nhom.id','=',$id)
            // ->where('lohang.so_luong_hien_tai','>',0)
            ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id','sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('lohang.so_luong_hien_tai as so_luong'),'sanpham.user_id')
            // ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id','sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('sum(lohang.so_luong_hien_tai) as so_luong'),'sanpham.user_id')
            ->groupBy('sanpham.id')
            ->orderBy('id','DESC');
        return $sanPhamsQuery;
    }

    public static function findAllInCate($id) {
        $sanPhamsQuery = DB::table('sanpham')                    
            ->join('loaisanpham','loaisanpham.id', '=', 'sanpham.loaisanpham_id')
            ->where('loaisanpham.id','=',$id);
        return $sanPhamsQuery;
    }

    public static function findAllWithPromotionInCate($id) {
        $sanPhamsQuery = DB::table('sanpham')     
            ->join('loaisanpham','loaisanpham.id', '=', 'sanpham.loaisanpham_id')       
            ->leftJoin('khuyenmai',function($query) {
                $query->on('sanpham.id','=','khuyenmai.sanpham_id')
                      ->where('khuyenmai.ngay_ket_thuc','>=', date('Y-m-d'));
            })
            ->leftJoin('lohang','sanpham.id', '=', 'lohang.sanpham_id')
            ->where('loaisanpham.id','=',$id)
            // ->where('lohang.so_luong_hien_tai','>',0)
            // ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id','sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('sum(lohang.so_luong_hien_tai) as so_luong'),'sanpham.user_id')
            ->select('sanpham.id','sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram', DB::raw('lohang.so_luong_hien_tai as so_luong'),'sanpham.user_id')
            ->groupBy('lohang.so_luong_hien_tai','lohang.id')
            ->orderBy('sanpham.ten','ASC');
        return $sanPhamsQuery;
    }

     public static function find10HotSale($name) {
        $sanPham = DB::table('sanpham')
                    ->join('lohang', 'sanpham.id', '=', 'lohang.sanpham_id')
                    ->join('chitietdonhang', 'sanpham.id', '=', 'chitietdonhang.sanpham_id')
                    ->join('donhang', 'donhang.id', '=', 'chitietdonhang.donhang_id')
                    ->select(DB::raw('sum(lohang.so_luong_da_ban) as daban'),'sanpham.id','sanpham.ten','sanpham.khuyenmai','sanpham.anh', 'lohang.so_luong_nhap','lohang.so_luong_hien_tai','sanpham.gia')
                    ->groupBy('sanpham.id')
                    ->orderBy('daban','desc')
                    ->take(10)
                    ->get();
        return $sanPham;
    }

    public static function noSaleAndImport() {
        return DB::table('lohang')
                    ->select(DB::raw('sum(so_luong_nhap) as nhap,sum(so_luong_da_ban) as ban,sum(so_luong_doi_tra) as tra,MONTH(created_at) as thang'))
                    ->orderBy(DB::raw('MONTH(created_at)'))
                    ->get();
    }

    public static function findImages($id) {
        $images = DB::table('sanpham')->where('id','=',$id)
                    ->select('sanpham.anh_0')
                    ->get();
        return $images;
    }

    public static function add($name,$description,$category,$price) {
    	$product = new Sanpham;
        $product->ten = $name;
        $product->loaisanpham_id = $category;
        $product->mo_ta = $description;
        $product->gia = $price;
        $product->user_id = null;
        $product->save();
        return $product->id;
    }

    public static function edit($id,$name,$description,$category,$price) {
            DB::table('sanpham')->where('id',$id)
                ->update([
                    'ten' => $name,
                    'loaisanpham_id'=>$category,
                    'mo_ta'=>$description,
                    'gia' => $price
                    ]);
    }

    public static function addByPartner($name,$description,$category,$price,$partner_id) {
    	$product = new Sanpham;
        $product->ten = $name;
        $product->loaisanpham_id = $category;
        $product->mo_ta = $description;
        $product->gia = $price;
        $product->user_id = $partner_id;
        $product->save();
        return $product->id;
    }

    public static function addImage($id,$imageName) {
            DB::table('sanpham')->where('id',$id)
                            ->update([
                                'anh_0'   => $imageName
                                ]);
    }

    public static function remove($id) {
        DB::table('sanpham')->where('id','=',$id)->delete();
    }
}
