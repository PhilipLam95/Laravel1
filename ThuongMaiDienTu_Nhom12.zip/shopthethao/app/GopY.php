<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class GopY extends Model
{
    protected $table = "gopy";
    protected $fillable = ['id','ten','email','noi_dung'];
	public $timestamps = true;

    public static function findAll() {
        $gopy = DB::table('gopy');
        return $gopy;
    }

    public static function add($name,$email,$message) {
        $gopy = new GopY;
        $gopy->ten = $product;
        $gopy->email = $email;
        $gopy->noi_dung = $message;
        $gopy->save();
    }

    public static function remove($id) {
        DB::table('gopy')->where('id','=',$id)->delete();
    }

}
