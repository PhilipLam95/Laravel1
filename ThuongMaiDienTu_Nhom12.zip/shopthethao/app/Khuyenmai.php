<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use DateTime;

class Khuyenmai extends Model
{
    protected $table = "khuyenmai";
    protected $fillable = ['id','phan_tram','ngay_ket_thuc','sanpham_id'];
	public $timestamps = true;

    public static function findAll() {
        $promotion = DB::table('khuyenmai');
        return $promotion;
    }

    public static function findAllWithProduct() {
        $promotionsQuery = DB::table('sanpham')            
            ->join('khuyenmai','sanpham.id','=','khuyenmai.sanpham_id')
            ->join('lohang','sanpham.id', '=', 'lohang.sanpham_id')
            ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id',DB::raw('khuyenmai.id as khuyenmai_id'),'sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram','khuyenmai.ngay_ket_thuc','khuyenmai.created_at', DB::raw('lohang.so_luong_hien_tai as so_luong'))
            ->where('khuyenmai.ngay_ket_thuc','>=', date('Y-m-d'))
            ->where('so_luong_hien_tai','>',0)
            ->where(DB::raw('sanpham.user_id'))
            ->groupBy('sanpham.id')
            ->orderBy('id','DESC');
        return $promotionsQuery;
    }

    public static function findAllWithProductOfPartner($id) {
        $promotionsQuery = DB::table('sanpham')            
            ->join('khuyenmai','sanpham.id','=','khuyenmai.sanpham_id')
            ->join('lohang','sanpham.id', '=', 'lohang.sanpham_id')
            ->select(DB::raw('max(lohang.id) as lo_moi'),'sanpham.id',DB::raw('khuyenmai.id as khuyenmai_id'),'sanpham.ten','sanpham.anh_0','lohang.so_luong_hien_tai','sanpham.gia','khuyenmai.phan_tram','khuyenmai.ngay_ket_thuc','khuyenmai.created_at', DB::raw('lohang.so_luong_hien_tai as so_luong'))
            ->where('khuyenmai.ngay_ket_thuc','>=', date('Y-m-d'))
            ->where('so_luong_hien_tai','>',0)
            ->where('sanpham.user_id',$id)
            ->groupBy('sanpham.id')
            ->orderBy('id','DESC');
        return $promotionsQuery;
    }
    public static function findOne($id) {
        $promotion = DB::table('khuyenmai')
        ->where('id','=',$id);
        return $promotion;
    }

    public static function add($percentage,$time,$product) {
        $promotion = new Khuyenmai;
        $promotion->sanpham_id = $product;
        $promotion->phan_tram = $percentage;
        $promotion->ngay_ket_thuc = date_format(new DateTime($time),"Y-m-d");
        $promotion->save();
    }

    public static function edit($id,$percentage,$time) {
            DB::table('khuyenmai')->where('id',$id)
                            ->update([
                                'phan_tram' => $percentage,
                                'ngay_ket_thuc' => date_format(new DateTime($time),"Y-m-d"),
                                ]);
    }

    public static function remove($id) {
        DB::table('khuyenmai')->where('id','=',$id)->delete();
    }

}
