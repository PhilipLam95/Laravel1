<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Binhluan extends Model
{
    protected $table = "binhluan";
    protected $fillable = ['id','noi_dung','trang_thai','sanpham_id','user_id'];
	public $timestamps = true;

    public static function findAll() {
        $comments = DB::table('binhluan');
        return $comments;
    }

    public static function findAllAccepted() {
        $comments = DB::table('binhluan')->where('binhluan.trang_thai',1);
        return $comments;
    }

    public static function findAllUnaccepted() {
        $comments = DB::table('binhluan')->where('binhluan.trang_thai',0);
        return $comments;
    }

    public static function findAllAcceptedWithProduct() {
        $comments = DB::table('binhluan')
                        ->join('sanpham','sanpham.id','=','binhluan.sanpham_id')
                        ->join('users','users.id','=','binhluan.user_id')
                        ->where('binhluan.trang_thai',1)
                        ->select('binhluan.*',DB::raw('sanpham.ten as ten_sanpham'),DB::raw('users.ten as ten'));
        return $comments;
    }

    public static function findAllAcceptedOfProduct($id) {
        $comments = DB::table('binhluan')
                        ->join('sanpham','sanpham.id','=','binhluan.sanpham_id')
                        ->join('users','users.id','=','binhluan.user_id')
                        ->where('binhluan.trang_thai',1)
                        ->where('binhluan.sanpham_id','=',$id)
                        ->select('binhluan.*',DB::raw('users.id as id_user'),DB::raw('users.ten as ten_user'),DB::raw('users.anh as anh'));
        return $comments;
    }

    public static function findAllUnacceptedWithProduct() {
        $comments = DB::table('binhluan')
                        ->join('sanpham','sanpham.id','=','binhluan.sanpham_id')
                        ->where('binhluan.trang_thai',0)
                        ->select('binhluan.*',DB::raw('sanpham.ten as ten_sanpham'));
        return $comments;
    }


    public static function findAllUnacceptedInProduct() {
        $comments = DB::table('binhluan')
                        ->join('sanpham','sanpham.id','=','binhluan.sanpham_id')
                        ->join('users','users.id','=','binhluan.user_id')
                        ->select('binhluan.*',DB::raw('sanpham.ten as ten_sanpham'),DB::raw('users.ten as ten'))
                        ->where('binhluan.trang_thai',0);
        return $comments;
    }

    public static function countUnaccepted() {
        $comments = DB::table('binhluan')->where('binhluan.trang_thai',0)->count();
        return $comments;
    }

    public static function findAllOfProduct($id) {
        $comments = DB::table('binhluan')->where('binhluan.sanpham_id','=',$id);
        return $comments;
    }

    public static function findAllOfCustomer($id) {
        $comments = DB::table('binhluan')->where('binhluan.user_id','=',$id);
        return $comments;
    }

    public static function acceptComments($id) {
    	DB::table('binhluan')
    		->where('id',$id)
    		->update(['trang_thai'=>1]);
    }

    public static function unacceptComments($id) {
        DB::table('binhluan')
            ->where('id',$id)
            ->update(['trang_thai'=>0]);
    }

    public static function add($id,$content,$product) {
        $comment = new Binhluan;
        $comment->noi_dung = $content;
        $comment->trang_thai = 0;
        $comment->user_id = $id;
        $comment->sanpham_id = $product;
        $comment->save();
    }

    public static function addCmtOfEmployee($id,$content,$product) {
        $comment = new Binhluan;
        $comment->noi_dung = $content;
        $comment->trang_thai = 1;
        $comment->user_id = $id;
        $comment->sanpham_id = $product;
        $comment->save();
    }

    public static function remove($id) {
        DB::table('binhluan')->where('id','=',$id)->delete();
    }

}
