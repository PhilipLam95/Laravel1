<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Loaisanpham extends Model {
    protected $table = 'loaisanpham';
	protected $fillable = ['ten','nhom_id','mo_ta','url','anh'];
	public $timestamps = true;

	public static function findAll() {
        $loaiSanPhamQuery = DB::table('loaisanpham');
        return $loaiSanPhamQuery;
    }

	public static function findAllWithGroup() {
        $loaiSanPhamQuery = DB::table('loaisanpham')
            ->leftJoin('nhom','loaisanpham.nhom_id', '=', 'nhom.id')
            ->select('loaisanpham.*','nhom.ten as ten_nhom')
            ->orderBy('nhom.id');
        return $loaiSanPhamQuery;
    }

    public static function findOne($id) {
        $loaiSanPhamQuery = DB::table('loaisanpham')->where('id','=',$id)->first();
        return $loaiSanPhamQuery;
    }

    public static function findAllInGroup($id) {
        $loaiSanPhamQuery = DB::table('loaisanpham')            
            ->join('nhom','loaisanpham.nhom_id', '=', 'nhom.id')
            ->where('nhom.id','=',$id)
            ->select('loaisanpham.*');
        return $loaiSanPhamQuery;
    }

    public static function add($name,$group) {
		$category = new Loaisanpham;
		$category->ten = $name;
		$category->nhom_id = $group;
        $category->save();
    }


    public static function edit($id,$name,$group) {
            DB::table('loaisanpham')->where('id',$id)
                ->update(['ten' => $name,'nhom_id'=>$group]);
    }

    public static function remove($id) {
        DB::table('loaisanpham')->where('id','=',$id)->delete();
    }

}
