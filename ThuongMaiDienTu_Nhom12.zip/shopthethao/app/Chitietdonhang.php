<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Chitietdonhang extends Model
{
    protected $table = "chitietdonhang";
    protected $fillable = ['sanpham_id','donhang_id','so_luong','thanh_tien','tinh_trang'];
	public $timestamps = true;

    public static function findAll() {
        $orderDetailQuery = DB::table('chitietdonhang');
        return $orderDetailQuery;
    }

    public static function findOne($id) {
        $orderDetailQuery = DB::table('chitietdonhang')->where('id','=',$id)->first();
        return $orderDetailQuery;
    }

    public static function findAllByInvoiceIDWithPrice($id) {
        $orderDetailQuery = DB::table('chitietdonhang')
                            ->join('sanpham','sanpham.id','=','chitietdonhang.sanpham_id')
                            ->where('donhang_id','=',$id)
                            ->select('chitietdonhang.*','sanpham.gia','sanpham.ten');
        return $orderDetailQuery;
    }

    public static function findAllByInvoiceID($id) {
        $orderDetailQuery = DB::table('chitietdonhang')
        ->join('sanpham','sanpham.id','=','chitietdonhang.sanpham_id')
        ->where('donhang_id','=',$id)
        ->select('chitietdonhang.*','sanpham.ten');
        return $orderDetailQuery;
    }

    public static function findAllByInvoiceIDWithProduct($id) {
        $orderDetailQuery = DB::table('chitietdonhang')
                                ->join('sanpham','sanpham.id','=','chitietdonhang.sanpham_id')
                                ->where('chitietdonhang.donhang_id','=',$id)
                                ->select('chitietdonhang.*',DB::raw('sanpham.ten as ten_sanpham'));
        return $orderDetailQuery;
    }

    public static function findHotSale() {
        return DB::table('chitietdonhang')
                ->where('donhang.tinh_trang',4)
                ->join('donhang','donhang.id','=','chitietdonhang.donhang_id')
                ->join('sanpham','sanpham.id','=','chitietdonhang.sanpham_id')
                ->select(
                    'sanpham_id',
                    DB::raw('SUM(so_luong) as ban'),
                    DB::raw('SUM(thanh_tien) as tien'),
                    'sanpham.ten'
                    )
                ->groupBy('sanpham_id')
                ->orderBy('tien', 'desc')
                ->take(10)
                ->get();
    }

    public static function add($product_id,$order_id,$quantity,$price) {
        $lohang = Lohang::findOneByProduct($product_id);
        if(!is_null($lohang)) {
            DB::table('lohang')
                    ->where('id',$lohang->id)
                    ->update([
                        'so_luong_dat_hang' => $lohang->so_luong_dat_hang + $quantity,
                        ]);
        }
        $detail = new Chitietdonhang;
        $detail->sanpham_id = $product_id;
        $detail->donhang_id = $order_id;
        $detail->so_luong = $quantity;
        $detail->thanh_tien = $price*$quantity;
        $detail->tinh_trang = 'Đang xử lý';
        $detail->save();
    }

    public static function updateNumber($productID,$productID,$number,$price) {
    		DB::table('chitietdonhang')
    			->where([['sanpham_id',$productID],['donhang_id',$productID] ])
    			->update([
    				'so_luong'=>$number,
    				'thanh_tien'=>($number*$price),
    				]);
    }

    public static function sum($id) {
    	return DB::table('chitietdonhang')->where('donhang_id','=',$id)
                    ->select(DB::raw('sum(thanh_tien) as tong'))->first();
    }


    public static function remove($id) {
        DB::table('chitietdonhang')->where('id','=',$id)->delete();
    }

    public static function removeByProductAndInvoice($productID,$orderID) {
        DB::table('chitietdonhang')
            ->where([['sanpham_id',$productID],['donhang_id',$orderID]])
            ->delete();
    }

    public static function updateStatus($id,$status) {
        DB::table('chitietdonhang')->where('id',$id)
            ->update(['tinh_trang' => $status]);
    }

}
