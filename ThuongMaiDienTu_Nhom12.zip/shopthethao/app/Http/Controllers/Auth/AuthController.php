<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Khachhang;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use Illuminate\Support\Facades\Input;
use Auth,Cart;
use DB,Mail;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware($this->guestMiddleware(), ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        $rules = [
            'name' =>'required',
            'email' =>'required|unique:users,email|regex:^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})^',
            'password' => 'required|min:3',
            'password_confirmation' =>'required|same:password',
            'phone'   =>'required',
            'address'   =>'required',
            'bank_id'   =>'required',
             'image' => 'mimes:jpeg,bmp,png|max:4000'
        ];

        $messages = [
            'required'=> 'Vui lòng không để trống trường này!',
            'email.unique'  =>'Email này đã được sử dụng!',
            'email.regex'  =>'Email không đúng định dạng!',
            'password.min' =>'Mật khẩu tối thiểu 3 kí tự!',
            'password.min' =>'Mật khẩu tối thiểu 3 kí tự!',
            'password_confirmation.same' =>'Mật khẩu không trùng khớp!',
            'mimes' => 'Vui lòng chọn đúng file ảnh',
            'image.max' => 'Vui lòng chọn file ảnh có kích thước không quá 4MB'
        ];
        return Validator::make($data,$rules,$messages);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        $token = str_random(32);
        $user = User::create([
            'ten' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'so_tai_khoan' => $data['bank_id'],
            'sdt' => $data['phone'],
            'dia_chi' => $data['address'],
            'loai_tai_khoan' => 'Khách hàng',
            'verifytoken' => $token,
            'trang_thai' => 'Chưa xác nhận'
        ]);

        $fileName = '';
        if (!is_null(Input::file('image')) && Input::file('image')->isValid()) {
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $user->id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/user/',$fileName);
            User::addImage($user->id,$fileName);
        } else {
            $file = 'resources/upload/user/placeholder.jpg';
            $fileName = 'resources/upload/user/'.$user->id.'.jpg';
            copy($file, $fileName);
            $fileName = $user->id.'.jpg';
            User::addImage($user->id,$fileName);
        }
        
        $name = $data['name'];
        $email = $data['email'];
        $tokens = [
            'token' => $token
        ];
        Mail::send('auth.emails.chaomung', $tokens, function ($message) use ($name,$email) {
            $message->from(env('MAIL_ADDRESS'), 'ADMIN');
            $message->to($email, $name);
            $message->subject('Đăng ký tài khoản tại Cửa hàng thể theo Thiên Minh!!!');
        });
        return $user;
    }

    public function postVerify(Request $request) {
        $user = User::findOne($request->id);
        if($user->trang_thai == 'Chưa xác nhận') {
            $token = $request->token;

            $sendDate = strtotime(str_replace('/', '-', $user->updated_at));
            $diff = abs($sendDate - time()) / 3600;       

            if( $diff < 24 && $user->verifytoken == $token) {
                User::updateStatus($user->id,'Hoạt động');
                User::updateToken($user->id,'');
                return "<script> alert('Xác nhận thành công. Vui lòng đăng nhập!'); window.location = '".url('/login')."';</script>";
            }
            return "<script> alert('Mã xác nhận sai!'); window.location = '".url('/')."';</script>";
        }
        return "<script> alert('Tài khoản đã xác nhận rồi!'); window.location = '".url('/')."';</script>";
    }

    public function getLogin() {
        return view('backend.login');
    }

    public function postLogin(LoginRequest $request) {
        $user = User::findOneByEmail($request->email);
        if($user->trang_thai != 'Chưa xác nhận' && $user->trang_thai != 'Ban') {
            $remember = (Input::has('remember')) ? true : false;
            if (Auth::attempt(['email' => $request->email, 'password' => $request->password],$remember)) {
                // Authentication passed...
                switch (Auth::user()->loai_tai_khoan) {
                    case 'Admin':
                    case 'Nhân viên':
                        return redirect('/dashboard/home');
                    case 'Đối tác':
                        return redirect('/partner/home');
                }
                return redirect('/');
            }
        } else if($user->trang_thai == 'Chưa xác nhận') {
            return view('auth.verify',['id'=>$user->id]);
        } 
        return "<script> alert('Tài khoản đã bị ban!'); window.location = '".url('/')."';</script>";
    }

    public function logout() {
        Auth::logout();
        Cart::destroy();
        return redirect('/');
    }
}