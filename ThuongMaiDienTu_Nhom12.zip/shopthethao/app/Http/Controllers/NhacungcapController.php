<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Requests\NhacungcapAddRequest;
use App\Http\Requests\NhacungcapEditRequest;
use App\Nhacungcap;

use DB;

class NhacungcapController extends Controller
{
    public function getList()
    {
        $vendors = Nhacungcap::findAll()->get();
    	return view('backend.nhacungcap.danhsach',['vendors'=>$vendors]);
    }

    public function getAdd()
    {
    	return view('backend.nhacungcap.them');
    }

    public function postAdd(NhacungcapAddRequest $request) {
        Nhacungcap::add($request->name,$request->phone,$request->address);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm thành công!!!');
        return redirect('/dashboard/vendor');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm nhà cung cấp thành công!!!']);
    }

    public function getDelete($id)
    {
        Nhacungcap::remove($id);
        session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa thành công!!!');
        return redirect('/dashboard/vendor');
        // ->with(['flash_level'=>'success','flash_message'=>'Xóa nhà cung cấp thành công!!!']);
    }

    public function getEdit($id)
    {
    	$vendor = Nhacungcap::findOne($id);
        return view('backend.nhacungcap.sua',['vendor'=>$vendor]);
    }

    public function postEdit(NhacungcapEditRequest $request, $id)
    {
        Nhacungcap::edit($id,$request->name,$request->phone,$request->address);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Chỉnh sửa thành công!!!');
        return redirect('/dashboard/vendor');
        // ->with(['flash_level'=>'success','flash_message'=>'Chỉnh sửa nhà cung cấp thành công!!!']);
    }
}
