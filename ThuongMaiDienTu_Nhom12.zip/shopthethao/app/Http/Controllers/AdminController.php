<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;
use Chartjs;
use App\Donhang;
use App\User;
use App\Sanpham;
use App\Binhluan;
use App\Chitietdonhang;
use App\Lohang;

class AdminController extends Controller {
    public function index() {
    	$noInvoice = Donhang::countUnapprove();
    	$noComment = Binhluan::countUnaccepted();
    	$noCustomer = User::countCustomers();
    	$noProduct = Sanpham::count();
    	$comments = Binhluan::findAllUnacceptedInProduct()->get();
        $thongke = Sanpham::noSaleAndImport();
        $banChay = Chitietdonhang::findHotSale();
        $nhapNhieu = Lohang::findHotImport();
        $muaNhieu = Donhang::find10HotSale();
        return view('backend.dashboard',['noInvoice' => $noInvoice,'noCustomer' => $noCustomer,'noProduct' => $noProduct,'noComment' => $noComment,'thongke' => $thongke,'banChay' => $banChay,'nhapNhieu' => $nhapNhieu,'muaNhieu' => $muaNhieu,'comments' => $comments]);
    }
}
