<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;
use App\Lohang;

class ThongkeController extends Controller
{
    public function getList() {
    	$stock = Lohang::findStock();
	    $hotSale = Lohang::findHotSale();
	   	$inactiveStock = Lohang::findInactiveStock();
    	return view('backend.thongke.tongquan',['stock'=>$stock,'hotSale'=>$hotSale,'inactiveStock'=>$inactiveStock]);
    }

    public function getImport() {
    	$title = 'Sản phẩm nhập vào';
    	$import = Lohang::findImport();
	    return view('backend.thongke.sanpham',['data'=>$import,'title'=>$title]);
    }

    public function getSale() {
    	$title = 'Sản phẩm bán ra';
    	$sale = Lohang::findSale();
	    return view('backend.thongke.sanpham',['data'=>$sale,'title'=>$title]);
    }

    public function getAvailable() {
    	$title = 'Sản phẩm hiện có';
    	$available = Lohang::findAvailable();
	    return view('backend.thongke.sanpham',['data'=>$available,'title'=>$title]);
    }

    public function getReturn() {
    	$title = 'Sản phẩm đổi trả';
    	$return = Lohang::findReturn();
	    return view('backend.thongke.sanpham',['data'=>$return,'title'=>$title]);
    }

    public function getHotSale() {
    	$title = 'Sản phẩm bán chạy';
    	$hotSale = Lohang::findHotSale();
	    return view('backend.thongke.sanpham1',['data'=>$hotSale,'title'=>$title]);
    }

    public function getInactiveStock() {
    	$title = 'Sản phẩm nhập vào';
    	$inactiveStock = Lohang::findInactiveStock();
	    return view('backend.thongke.sanpham1',['data'=>$inactiveStock,'title'=>$title]);
    }
}
