<?php

namespace App\Http\Controllers;

//use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Requests\SanphamAddRequest;
use App\Http\Requests\SanphamEditRequest;
use App\Sanpham;
use App\Nhom;
use App\Loaisanpham;
use App\Donhang;
use App\Khuyenmai;
use DB;
use Request;
use File;
use Illuminate\Support\Facades\Input;
use Auth;

class SanphamController extends Controller {
    public function getList() {
        $products = Sanpham::findAllWithCate()->where(DB::raw('sanpham.user_id'))->get();
        $deletedProducts = Sanpham::findAllWithCateOnlyTrashed()->get();
    	return view('backend.sanpham.danhsach',
                    ['products'=>$products, 'deletedProducts'=>$deletedProducts]);
    }

    public function remove($id) {   
        $images = Sanpham::findImages($id);
        foreach ($images as $image) {
            File::delete('resources/upload/sanpham/'.$image->anh_0);
        }
    	$sanpham = Sanpham::remove($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa sản phẩm thành công!!!');
        return redirect('dashboard/product');
        // ->with(['flash_level'=>'success','flash_message'=>'Xóa sản phẩm thành công!!!']);
    }

    public function getAdd() {
        $groups = Nhom::findAll()->get();
        $categories = Loaisanpham::findAllInGroup($groups[0]->id)->get();
    	return view('backend.sanpham.them',['categories'=>$categories,'groups'=>$groups]);
    }

    public function postAdd(SanphamAddRequest $request) {
        $id = Sanpham::add($request->name,$request->description,$request->category,$request->price);
        if (Input::file('image')->isValid()) {
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/sanpham/',$fileName);
            Sanpham::addImage($id,$fileName);
        }
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm sản phẩm thành công!!!');
        return redirect('dashboard/product');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm  sản phẩm thành công!!!']);
    }

    public function getEdit($id) {
        $product = Sanpham::findOne($id);
        $productGroup = Loaisanpham::findOne($product->loaisanpham_id)->nhom_id;
        $groups = Nhom::findAll()->get();
        $categories = Loaisanpham::findAllInGroup($productGroup)->get();
        return view('backend.sanpham.sua',['categories'=>$categories,'product'=>$product,'groups'=>$groups,'productGroup'=>$productGroup]);
    }

    public function postEdit($id, SanphamEditRequest $request) {
        Sanpham::edit($id,$request->name,$request->description,$request->category,$request->price);
        if (!is_null(Input::file('image')) && Input::file('image')->isValid()) {
            File::delete('resources/upload/sanpham/'.$request->currentImage);
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/sanpham/',$fileName);
            Sanpham::addImage($id,$fileName);
        }
		session()->flash('flash_level','success');
		session()->flash('flash_message','Cập nhật sản phẩm thành công!!!');
        return redirect('dashboard/product');
        // ->with(['flash_level'=>'success','flash_message'=>'Chỉnh sửa sản phẩm thành công!!!']);
    }

    public function getListByPartner() {
        $products = Sanpham::findAllWithCateOfPartner(Auth::user()->id)->get();
        $orders = Donhang::findAllByPartner(Auth::user()->id)->get();
        $promotions = Khuyenmai::findAllWithProductOfPartner(Auth::user()->id)->get();
    	return view('partner.danhsach',['products'=>$products, 'orders'=>$orders, 'promotions'=>$promotions]);
    }

    public function getAddByPartner() {
        $categories = Loaisanpham::findAll()->get();
    	return view('partner.them',['categories'=>$categories]);
    }

    public function getEditByPartner($id) {
        $categories = Loaisanpham::findAll()->get();
        $product = Sanpham::findOne($id);
        return view('partner.sua',['categories'=>$categories,'product'=>$product]);
    }

    public function postAddByPartner(SanphamAddRequest $request) {
        $id = Sanpham::addByPartner($request->name,$request->description,$request->category,$request->price,Auth::user()->id);
        if (Input::file('image')->isValid()) {
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/sanpham/',$fileName);
            Sanpham::addImage($id,$fileName);
        }
        echo "<script> alert('Thêm  sản phẩm thành công!'); window.location = '".url('/partner/home')."';</script>";
        // return redirect('partner/home')->with(['flash_level'=>'success','flash_message'=>'Thêm  sản phẩm thành công!!!']);
    }

    public function removeByPartner($id) {   
        $images = Sanpham::findImages($id);
        foreach ($images as $image) {
            File::delete('resources/upload/sanpham/'.$image->anh_0);
        }
    	$sanpham = Sanpham::remove($id);
        echo "<script> alert('Xóa sản phẩm thành công!'); window.location = '".url('/partner/home')."';</script>";
        // return redirect('partner/home')->with(['flash_level'=>'success','flash_message'=>'Xóa sản phẩm thành công!!!']);
    }

    public function postEditByPartner($id, SanphamEditRequest $request) {
        Sanpham::edit($id,$request->name,$request->description,$request->category,$request->price);
        if (!is_null(Input::file('image')) && Input::file('image')->isValid()) {
            File::delete('resources/upload/sanpham/'.$request->currentImage);
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/sanpham/',$fileName);
            Sanpham::addImage($id,$fileName);
        }
        echo "<script> alert('Chỉnh sửa sản phẩm thành công!'); window.location = '".url('/partner/home')."';</script>";
        // return redirect('partner/home')->with(['flash_level'=>'success','flash_message'=>'Chỉnh sửa sản phẩm thành công!!!']);
    }

}
