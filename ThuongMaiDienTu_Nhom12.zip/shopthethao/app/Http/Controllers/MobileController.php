<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use DB;
use JWTAuth;
use App\Sanpham;
use App\Loaisanpham;
use App\Donhang;
use App\User;
use App\Nhom;
use App\Khuyenmai;
use App\Binhluan;
use App\Chitietdonhang;
use App\Http\Requests\ThanhtoanRequest;
use App\Http\Requests\BinhluanRequest;
use Illuminate\Support\Facades\Input;
use GuzzleHttp\Client;

class MobileController extends Controller {

    public function login(Request $request) {
        $input = $request->all();
        $user = User::findOneByEmail($request->email);
        if (is_null($user)) {
            return response()->json(['result' => 'wrong email or password.']);
        } elseif ($user->trang_thai =='Chưa xác nhận') {
            return response()->json(['result' => 'Not confirm.']);
        } elseif ($user->trang_thai == 'Ban') {
            return response()->json(['result' => 'Banned.']);
        } elseif ($user->loai_tai_khoan != 'Khách hàng') {
            return response()->json(['result' => 'Not customer']);
        } elseif (!$token = JWTAuth::attempt($input)) {
            return response()->json(['result' => 'wrong email or password.']);
        }
        return response()->json(['result' => $token,'user' => $user]);
    }

    public function signup(Request $request) {
        $user = User::signup($request->name,$request->email,$request->phone,$request->address,$request->password,$request->bank_id);
        if($user != null)
            return response()->json(['result' => 'Thành công']);
        return response()->json(['result' => 'Thất bại']);
    }

    public function findAllWithPromotionToMobile() {
        $products = Sanpham::findAllWithPromotion()->get();
        for($i=0;$i < count($products);$i++) {
            $products[$i]->anh_0 = asset('resources/upload/sanpham/'.$products[$i]->anh_0);
        }

    	return json_encode($products,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function findOneWithPromotionToMobile($id) {
        $product = Sanpham::findOneWithPromotion($id);
        $product->anh_0 = asset('resources/upload/sanpham/'.$product->anh_0);
    	return json_encode($product,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }


    public function findAllCommentsOfProduct($id) {
        $comments = Binhluan::findAllAcceptedOfProduct($id)->get();
        for($i=0;$i < count($comments);$i++) {
            $comments[$i]->anh = asset('resources/upload/user/'.$comments[$i]->anh);
        }
    	return json_encode($comments,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function findAllPromotionsWithProduct() {
        $products = Khuyenmai::findAllWithProduct()->get();
        for($i=0;$i < count($products);$i++) {
            $products[$i]->anh_0 = asset('resources/upload/sanpham/'.$products[$i]->anh_0);
        }
    	return json_encode($products,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function checkout(Request $request) {
        if (! $user = JWTAuth::parseToken()->authenticate()) {
            return response()->json(['result'=>'user_not_found']);
        }
        $client = new Client();
        $res = $client->post('http://localhost:8080/bank/transfer',array(
                                'headers'=>array('Content-Type'=>'application/json'),
                                'json'=>array(
                                    'id' =>  (int)$request->bank_id,
                                    'pin' => (int)$request->pin,
                                    'ten' => $request->name_user,
                                    'sdt' => $request->phone_user,
                                    'dia_chi' => $request->address_user,
                                    'email' => $request->email_user,
                                    'so_tien' => (int)$request->total,
                                    'receiver_id' => (int)env('BANK_ID')
                                    )
                                )
                            );
        $result = (string) $res->getBody();
        if($result == 'success') {
            $token = str_random(32);
            User::editNoPass($user->id,$request->name_user,$request->email_user,$request->bank_id,$request->phone_user,$request->address_user);

            $order_id = Donhang::add($user->id,$request->name,$request->phone,$request->email,$request->address,$request->note,$request->total,$token);
            
            $cart = $request->cart;
            foreach ($cart as $item) {
                Chitietdonhang::add($item["id"],$order_id,$item["quantity"],$item["price"]);
            }
            $hoadon = [
                'id'=> $order_id->id,
                'nguoi_nhan'=> $request->name,
                'email' => $request->email,
                'sdt' => $request->phone,
                'dia_chi' => $request->address,
                'ghi_chu' => $request->note,
                'tong_tien' => $request->total,
                'khachhang_id' => $user->id,
                'token' => $token
                ];
            $email = $request->email_user;
            $name = $request->name_user;
            Mail::send('auth.emails.hoadon', $hoadon, function ($message) use ($email,$name) {
                $message->from(env('MAIL_ADDRESS'), 'ADMIN');
                $message->to($email, $name);
                $message->subject('Hóa đơn mua hàng tại Cửa hàng thể theo Thiên Minh!!!');
            });
            return response()->json(['result' => 'Thành công']);
        } else if($result == 'too_much') {
            return response()->json(['result' => 'Quá hạn mức thanh toán']);
        } else if($result == 'wrong information') {
            return response()->json(['result' => 'Thông tin tài khoản sai']);
        }
        return response()->json(['result' => 'Không đủ tiền trong tài khoản']);
    }

    public function comment(Request $request) {
        return response()->json(['result' => $request->user_id]);
        Binhluan::add($request->user_id,$request->content,$request->product_id);
        return response()->json(['result' => 'Thành công']);
    }

    public function getFind(Request $request) {
        $keyword = Input::get("keyword");
        $category = Input::get("category");
        $group = Input::get("group");
        $price = Input::get("price");
        if($price == 0) {
            $price = PHP_INT_MAX;
        }
        if($category != '') {
            $products = Sanpham::findAllLikeKeyword($keyword)
            ->where('sanpham.loaisanpham_id','=',$category)
            ->where('sanpham.gia','<=',$price)
            ->get();
        }
        else if($group != '') {
            $products = Sanpham::findAllLikeKeyword($keyword)
            ->join('loaisanpham','loaisanpham.id', '=', 'sanpham.loaisanpham_id')       
            ->where('loaisanpham.nhom_id','=',$group)
            ->where('sanpham.gia','<=',$price)
            ->get();
        } else {
            $products = Sanpham::findAllLikeKeyword($keyword)
            ->where('sanpham.gia','<=',$price)
            ->get();
        }
        for($i=0;$i < count($products);$i++) {
            $products[$i]->anh_0 = asset('resources/upload/sanpham/'.$products[$i]->anh_0);
        }
        return json_encode($products,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function getOrder() {
        if (! $user = JWTAuth::parseToken()->authenticate()) {
            return response()->json(['result'=>'user_not_found']);
        } else {
            $orders = Donhang::findAllOfCustomer($user->id)->get();
            return response()->json(['result'=>'success','orders'=>$orders]);
        }
    }

}
