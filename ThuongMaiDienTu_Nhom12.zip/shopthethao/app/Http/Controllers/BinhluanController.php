<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;
use App\Binhluan;
use App\GopY;

class BinhluanController extends Controller {
    public function getList() {
        $acceptedComments = Binhluan::findAllAcceptedWithProduct()->orderBy('id','DESC')->get();
        $unacceptedComments = Binhluan::findAllUnacceptedWithProduct()->orderBy('id','DESC')->get();
        $comments = collect($acceptedComments)->merge(collect($unacceptedComments))->sortByDesc('id');
        $gopy = GopY::findAll()->get();
    	return view('backend.binhluan.danhsach',['comments'=>$comments,'acceptedComments'=>$acceptedComments,'unacceptedComments'=>$unacceptedComments,'gopy'=>$gopy]);
    }

    public function remove($id) {
    	Binhluan::remove($id);
        return redirect('dashboard/comment')->with(['flash_level'=>'success','flash_message'=>'Xóa thành công!!!']);
    }

    public function removeGopy($id) {
    	GopY::remove($id);
        return redirect('dashboard/comment')->with(['flash_level'=>'success','flash_message'=>'Xóa thành công!!!']);
    }

    public function acceptComments($id) {
    	Binhluan::acceptComments($id);
    	return redirect('dashboard/comment')->with(['flash_level'=>'success','flash_message'=>'Bình luận đã được chấp nhận!!!']);
    }

    public function unacceptComments($id) {
        Binhluan::unacceptComments($id);
        return redirect('dashboard/comment')->with(['flash_level'=>'success','flash_message'=>'Bình luận đã bị hủy chấp nhận!!!']);
    }
}
