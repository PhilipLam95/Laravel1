<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Requests;
use App\Donhang;
use App\User;
use Illuminate\Support\Facades\Route;

class UserController extends Controller
{
    public function getCustomer() {
        $customers = User::findAllCustomers()->get();
    	return view('backend.khachhang.danhsach',['customers'=>$customers]);
    }

    public function getPartner() {
        $customers = User::findAllPartners()->get();
    	return view('backend.doitac.danhsach',['customers'=>$customers]);
    }

    public function getEmployee() {
        $employees = User::findAllEmployees()->get();
    	return view('backend.nhanvien.danhsach',['data'=>$employees]);
    }

    public function remove($id) {
    	$id_user = User::remove($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa tài khoản thành công!!!');
        return redirect()->back();
        // ->with(['flash_level'=>'success','flash_message'=>'Xóa tài khoản thành công!!!']);
    }

    public function ban($id) {
    	$id_user = User::updateStatus($id,'Ban');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Ban tài khoản thành công!!!');
        return redirect()->back();
        // ->with(['flash_level'=>'success','flash_message'=>'Ban tài khoản thành công!!!']);
    }

    public function unban($id) {
    	$id_user = User::updateStatus($id,'Hoạt động');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Ban tài khoản thành công!!!');
        return redirect()->back();
        // ->with(['flash_level'=>'success','flash_message'=>'Ban tài khoản thành công!!!']);
    }

    public function verify($id) {
    	User::updateStatus($id,'Hoạt động');
        User::updateToken($user->id,'');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xác nhận tài khoản thành công!!!');
        return redirect('dashboard/customer');
        // ->with(['flash_level'=>'success','flash_message'=>'Xác nhận tài khoản thành công!!!']);
    }

    public function upgrade($id) {
    	User::updateRole($id,'Đối tác');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Nâng cấp tài khoản thành công!!!');
        return redirect('dashboard/partner');
        // ->with(['flash_level'=>'success','flash_message'=>'Xác nhận tài khoản thành công!!!']);
    }

    public function downgrade($id) {
    	User::updateRole($id,'Khách hàng');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Hạ cấp tài khoản thành công!!!');
        return redirect('dashboard/customer');
        // ->with(['flash_level'=>'success','flash_message'=>'Xác nhận tài khoản thành công!!!']);
    }

    public function getAddEmployee() {
    	return view('backend.nhanvien.them');
    }

    public function postAddEmployee(Request $request) {
        User::add($request->name,$request->email,$request->phone,$request->role,$request->address,'');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm tài khoản thành công!!!');
    	return redirect('dashboard/employee');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm thành công!!!']);
    }

    public function getAddCustomer() {
    	return view('backend.khachhang.them');
    }

    public function postAddCustomer(Request $request) {
        User::add($request->name,$request->email,$request->phone,'Khách hàng',$request->address,$request->bankId);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm tài khoản thành công!!!');
    	return redirect('dashboard/customer');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm thành công!!!']);
    }

    public function getAddPartner() {
    	return view('backend.doitac.them-dt');
    }

    public function postAddPartner(Request $request) {
        User::add($request->name,$request->email,$request->phone,'Đối tác',$request->address,$request->bankId);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm tài khoản thành công!!!');
    	return redirect('dashboard/partner');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm thành công!!!']);
    }

    public function getHistory($id) {
        $customer = User::findOne($id);
        $order = Donhang::findHistoryOfCustomer($id)->get();
        return view('backend.khachhang.lichsu',['customer'=>$customer,'order'=>$order]);
    }
}
