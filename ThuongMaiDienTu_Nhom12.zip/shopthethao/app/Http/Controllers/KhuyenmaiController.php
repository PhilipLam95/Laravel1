<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Sanpham;
use App\Khuyenmai;
use App\Sanphamkhuyenmai;
use DB;
use File,Input;
use Auth;

class KhuyenmaiController extends Controller {
    public function getList() {
        $promotions = Khuyenmai::findAllWithProduct()->get();
    	return view('backend.khuyenmai.danhsach',['promotions'=>$promotions]);
    }

    public function getAdd() {
         $products = Sanpham::findAll()->where(DB::raw('sanpham.user_id'))->get();
    	return view('backend.khuyenmai.them',['products'=>$products]);
    }

    public function postAdd(Request $request) {
        Khuyenmai::add($request->percentage,$request->time,$request->product);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm thành công!!!');
        return redirect('dashboard/promotion');
    }

    public function getDelete($id) {
    	Khuyenmai::remove($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa thành công!!!');
        return redirect('dashboard/promotion');
    }

    public function getEdit($id) {
        $products = Sanpham::findAll()
        ->get();
    	$promotion = DB::table('khuyenmai')->where('id',$id)->first();
        return view('backend.khuyenmai.sua',['promotion'=>$promotion,'products'=>$products]);
    }

    public function postEdit(Request $request,$id) {
        Khuyenmai::edit($id,$request->percentage,$request->time);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Sửa thành công!!!');
        return redirect('dashboard/promotion');
    }

    public function getAddByPartner() {
         $products = Sanpham::findAllOfPartner(Auth::user()->id)->get();
    	return view('partner.khuyenmai.them',['products'=>$products]);
    }

    public function postAddByPartner(Request $request) {
        Khuyenmai::add($request->percentage,$request->time,$request->product);
        echo "<script> alert('Thêm  thành công!'); window.location = '".url('/partner/home')."';</script>";
    }

    public function getEditByPartner($id) {
    	$promotion = DB::table('khuyenmai')->where('id',$id)->first();
         $products = Sanpham::findAllOfPartner(Auth::user()->id)->get();
        return view('partner.khuyenmai.sua',['products'=>$products,'promotion'=>$promotion]);
    }

    public function postEditByPartner(Request $request,$id) {
        Khuyenmai::edit($id,$request->percentage,$request->time);
        echo "<script> alert('Sửa thành công!'); window.location = '".url('/partner/home')."';</script>";
    }

    public function getDeleteByPartner($id) {
    	Khuyenmai::remove($id);
        echo "<script> alert('Xóa thành công!'); window.location = '".url('/partner/home')."';</script>";
    }

}
