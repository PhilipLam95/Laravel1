<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\GiaohangRequest;
use App\Donhang;
use App\Sanpham;
use App\Lohang;
use App\PhieuXuatKho;
use App\User;
use App\Chitietdonhang;
use App\GiaoHang;
use DB;
use PDF;
use GuzzleHttp\Client;
use Auth;

class DonhangController extends Controller
{
    public function getList() {
		$unacceptedOrders = Donhang::findAllUnaccepted()->orderBy('id','DESC')->get();
        $deliveringOrders = Donhang::findAllDelivery()->orderBy('id','DESC')->get();
		$orders = Donhang::findAll()->get();
    	return view('backend.donhang.danhsach',['orders'=>$orders,'unacceptedOrders'=>$unacceptedOrders,'deliveringOrders'=>$deliveringOrders]);
    }

    public function getEdit($id) {
    	$order = Donhang::findOne($id);
    	$customer = User::findOne($order->khachhang_id);
    	$orderDetails = Chitietdonhang::findAllByInvoiceIDWithProduct($order->id)->get();
		return view('backend.donhang.sua',['order'=>$order,'customer'=>$customer,'orderDetails'=>$orderDetails]);
    }

    public function postEdit(Request $request,$id) {
    	Donhang::edit($id,$request->name,$request->phone,$request->email,$request->address,$request->note);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Chỉnh sửa thành công!!!');
    	return redirect('dashboard/order');
    }

    public function pdf($id) {
        $order = Donhang::findOne($id);
        $orderDetails = Chitietdonhang::findAllByInvoiceID($id)->get();
        $customer = User::findOne($order->khachhang_id);
        $pdf = PDF::loadView('backend.donhang.hoadon',['donhang'=>$order,'chitietdonhang'=>$orderDetails,'khachhang'=>$customer]);
        return $pdf->stream();
    }

	public function verify($id) {
		Donhang::updateStatus($id,'Đã xác nhận');
		Donhang::updateToken($id,'');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xác nhận thành công!!!');
    	return redirect('dashboard/order');
    }

	public function process($id) {
		Donhang::updateStatus($id,'Đang xử lý');
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xác nhận thành công!!!');
    	return redirect('dashboard/order');
    }

	public function finish($id) {
		$finish = true;
		$orderDetails = Chitietdonhang::findAllByInvoiceID($id)->get();
		foreach ($orderDetails as $orderDetail) {

			$product = Sanpham::findOne($orderDetail->sanpham_id);
			$result = '';
			$client =  new Client();
			if(!is_null($product->user_id)) {
				$user = User::findOne($product->user_id);
				$res = $client->post('http://localhost:8080/bank/transfer',array(
										'headers'=>array('Content-Type'=>'application/json'),
										'json'=>array(
											'id' => (int)env('BANK_ID'),
											'pin' => (int)env('BANK_PIN'),
											'ten' => env('NAME'),
											'sdt' => env('PHONE_NUMBER'),
											'dia_chi' => env('ADDRESS'),
											'email' => env('MAIL_ADDRESS'),
											'so_tien' => (int)($orderDetail->thanh_tien * 0.8),
											'receiver_id' => (int)$user->so_tai_khoan
											)
										)
									);
				$result = (string) $res->getBody();
				if($result == 'too_much') {
					session()->flash('flash_level','warning');
					session()->flash('flash_message','Quá định mức thanh toán!!!!');
					return redirect()->back();
				} elseif($result == 'not enough') {
					session()->flash('flash_level','danger');
					session()->flash('flash_message', 'Tài khoản của cửa hàng không còn đủ tiền thanh toán!!!!');
					return redirect()->back();
				} elseif($result == 'wrong information') {
					session()->flash('flash_level','danger');
					session()->flash('flash_message','Sai thông tin tài khoản cửa hàng!!!!');
					return redirect()->back();
				} else {
					Lohang::sell($orderDetail->sanpham_id,$orderDetail->so_luong);
					Chitietdonhang::updateStatus($id,'Hoàn tất');
				}
			}
			Donhang::updateStatus($id,'Hoàn tất');
			session()->flash('flash_level','success');
			session()->flash('flash_message','Hoàn tất xử lý đơn hàng!!!');
			return redirect('dashboard/order');
			}
    }

	public function deliveryOrder($id) {
		$finish = true;
		$orderDetails = Chitietdonhang::findAllByInvoiceID($id)->get();
		foreach ($orderDetails as $orderDetail) {
			$count = Lohang::getNumberOfProduct($orderDetail->sanpham_id);
			if($orderDetail->so_luong > $count){
				$product = Sanpham::findOne($orderDetail->sanpham_id);
				session()->flash('flash_level','success');
				session()->flash('flash_message','Không có đủ hàng để giao cho mặt hàng '.$product->ten);
				return redirect('dashboard/order');
			}
		}
		foreach ($orderDetails as $orderDetail) {
			Lohang::deliver($orderDetail->sanpham_id,$orderDetail->so_luong);
			Chitietdonhang::updateStatus($id,'Đang giao hàng');
		}
		Donhang::updateStatus($id,'Đang giao hàng');
		Donhang::setDeliverTime($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Hoàn tất xử lý đơn hàng!!!');
		return redirect('dashboard/order');
    }

	public function cancel($id) {
		$tong_tien = 0;
		$order = Donhang::findOne($id);
		$orderDetails = Chitietdonhang::findAllByInvoiceID($id)->get();
		if($order->tinh_trang == 'Đang giao hàng') {
			return "<script> alert('Đơn hàng đang giao hàng. Không hủy đơn hàng lúc này!'); window.location = '".url('/dashboard/order')."';</script>";
		} 
		$tong_tien = $order->tong_tien;
		if( $tong_tien > 0) {
			$user = User::findOne($order->khachhang_id);
			$client =  new Client();
			$res = $client->post('http://localhost:8080/bank/transfer',array(
									'headers'=>array('Content-Type'=>'application/json'),
									'json'=>array(
										'id' => (int)env('BANK_ID'),
										'pin' => (int)env('BANK_PIN'),
										'ten' => env('NAME'),
										'sdt' => env('PHONE_NUMBER'),
										'dia_chi' => env('ADDRESS'),
										'email' => env('MAIL_ADDRESS'),
										'so_tien' => (int)$tong_tien,
										'receiver_id' => (int)$user->so_tai_khoan
										)
									)
								);
			$result = (string) $res->getBody();
			if($result == 'success') {
				Donhang::updateStatus($id,'Hủy');
			} elseif($result == 'too_much') {
				session()->flash('flash_level','warning');
				session()->flash('flash_message','Quá định mức thanh toán!!!!');
				return redirect()->back();
			} elseif($result == 'not enough') {
				session()->flash('flash_level','danger');
				session()->flash('flash_message','Tài khoản của cửa hàng không còn đủ tiền để trả lại!!!!');
				return redirect()->back();
			} elseif($result == 'wrong information') {
				session()->flash('flash_level','danger');
				session()->flash('flash_message','Sai thông tin tài khoản cửa hàng!!!!');
				return redirect()->back();
			}
			foreach ($orderDetails as $item) {
				if($item->tinh_trang != 'Giao hàng' || $item->tinh_trang != 'Hoàn tất') {
					Lohang::cancel($item->sanpham_id,$item->so_luong);
					Chitietdonhang::updateStatus($item->id,'Hủy');
				}
			}
			Donhang::updateStatus($id,'Hủy');
		}
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xác nhận hủy thành công!!!!');
		return redirect('dashboard/order');
    }

    public function getListByPartner() {
		$orders = Donhang::findAllByPartner(Auth::user()->id)->get();
    	return view('partner.donhang',['orders'=>$orders]);
    }
	
    public function getOrderDetailForPartner($id) {
    	$order = Donhang::findOne($id);
    	$customer = User::findOne($order->khachhang_id);
    	$orderDetails = Chitietdonhang::findAllByInvoiceIDWithProduct($order->id)
                                        ->where('sanpham.user_id','=',Auth::user()->id)
                                        ->get();
		return view('partner.order-detail',['order'=>$order,'customer'=>$customer,'orderDetails'=>$orderDetails]);
    }

}
