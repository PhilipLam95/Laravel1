<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\NhomAddRequest;
use App\Http\Requests\NhomEditRequest;
use App\Nhom;
use App\Sanpham;
use DB;
use Input,File;

class NhomController extends Controller {
    public function findAllToMobile() {
        $groups = Nhom::findAll()->paginate(12);
    	return $groups;
    }

    public function getList(){
    	$groups = Nhom::findAll()->get();
    	return view('backend.nhom.danhsach',['groups'=>$groups]);
    }
    
    public function getAdd() {
    	return view('backend.nhom.them');
    }

    public function postAdd(NhomAddRequest $request)
    {
        Nhom::add($request->name);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm thành công!!!');
    	return redirect('dashboard/group');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm nhóm thực phẩm thành công!!!']);
    }

    public function getEdit($id) {
    	$nhom = Nhom::findOne($id);
    	return view('backend.nhom.sua',['nhom'=>$nhom]);
    }

    public function postEdit(NhomEditRequest $request, $id) {
        Nhom::edit($id,$request->name);
        session()->flash('flash_level','success');
		session()->flash('flash_message','Chỉnh sửa thành công!!!');
    	return redirect('dashboard/group');
        // ->with(['flash_level'=>'success','flash_message'=>'Cập nhật thành công!!!']);
    }

    public function remove($id) {
		Nhom::remove($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa thành công!!!');
        return redirect('dashboard/group');
        // ->with(['flash_level'=>'success','flash_message'=>'Xóa loại sản phẩm thành công!!!']);
	}
}
