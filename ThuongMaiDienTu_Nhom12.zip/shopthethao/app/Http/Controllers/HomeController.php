<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB,Cart,Mail;
use App\Sanpham;
use App\Donhang;
use App\Khuyenmai;
use App\Quangcao;
use App\Binhluan;
use App\Loaisanpham;
use App\Lohang;

use App\Nhom;
use App\User;
use App\GopY;
use App\Chitietdonhang;
use Auth;
use App\Http\Requests\ThanhtoanRequest;
use App\Http\Requests\BinhluanRequest;
use Illuminate\Support\Facades\Input;
use File;
use GuzzleHttp\Client;

class HomeController extends Controller {
    public function index() {
        $groups = Nhom::findAll()->get();
        $products = Sanpham::findAllWithPromotion()->take(12)->get();
        $advertisements = Quangcao::findAllAccepted()->get();
        $sidebarData = Loaisanpham::findAllWithGroup()->get();
        return view ('frontend.pages.home',['products'=>$products,'advertisements'=>$advertisements,'sidebarData'=>$sidebarData,'groups'=>$groups]);
    }

    public function admin() {
        return view('backend.dashboard');
    }

    public function getCategory($id) {
        $groups = Nhom::findAll()->get();
        $products = Sanpham::findAllWithPromotionInCate($id)->paginate(12);
        $sidebarData = Loaisanpham::findAllWithGroup()->get();
        return view('frontend.pages.products',['products'=>$products,'sidebarData'=>$sidebarData,'groups'=>$groups]);
    }

    public function getGroupList() {
        $groups = Nhom::findAll()->get();
        return json_encode($groups,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function getGroup($id) {
        $categories = Loaisanpham::findAllInGroup($id)->get();
        return json_encode($categories,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function products() {
        $groups = Nhom::findAll()->get();
        $products = Sanpham::findAllWithPromotion()->paginate(12);
        $sidebarData = Loaisanpham::findAllWithGroup()->get();
        return view('frontend.pages.products',['products'=>$products,'sidebarData'=>$sidebarData,'groups'=>$groups]);
    }

    public function promotions() {
        $groups = Nhom::findAll()->get();
        $products = Khuyenmai::findAllWithProduct()->paginate(12);
        $sidebarData = Loaisanpham::findAllWithGroup()->get();
        return view('frontend.pages.products',['products'=>$products,'sidebarData'=>$sidebarData,'groups'=>$groups]);
    }

    public function productDetails($id) {
        $groups = Nhom::findAll()->get();
        $product = Sanpham::findOneWithPromotion($id);
        $sidebarData = Loaisanpham::findAllWithGroup()->get();
        $comments = Binhluan::findAllAcceptedOfProduct($id)->get();
        return view('frontend.pages.product-details',['product'=>$product,'sidebarData'=>$sidebarData,'comments'=>$comments,'groups'=>$groups]);
    }

    public function contact() {
        return view('frontend.pages.contact');
    }

    public function cart() {
        return view('frontend.pages.cart');
    }

    public function getBuy($id) {
        $product = Sanpham::findOneWithPromotion($id);
        $price = 0;
        if (is_null($product->phan_tram)) {
            $price = $product->gia;
        } else {
            $price = $product->gia * ( 100 - $product->phan_tram) * 0.01;
        }
        Cart::add(array( 'id' => $product->id, 'name' => $product->ten, 'qty' => 1, 'price' => $price));
        return redirect()->back();
    }

    public function postBuy(Request $request) {
        $id = $request->id;
        $number = $request->number;
        $product = Sanpham::findOneWithPromotion($id);
        $price = 0;
        if(!is_null($product->so_luong) && $number > $product->so_luong - $product->so_luong_dat_hang) {
            session()->flash('flash_message','Cửa hàng không đủ số lượng hàng như bạn đã đặt! Chúng tôi chỉ có thể cung cấp tối đa ' . ($product->so_luong - $product->so_luong_dat_hang) . ' mặt hàng!!!');
            return redirect()->back();
        }
        if (is_null($product->phan_tram)) {
            $price = $product->gia;
        } else {
            $price = $product->gia * ( 100 - $product->phan_tram) * 0.01 * $number;
        }
        Cart::add(array( 'id' => $product->id, 'name' => $product->ten, 'qty' => $number, 'price' => $price));
        return redirect()->back();
    }

    public function updateCart(Request $request) {
        $items = $request->input('item',[]);
        $removes = $request->input('remove',[]);
        $quantitys = $request->input('quantity',[]);

        $count = count($items);
        for( $i=0; $i < $count; $i++) {
            Cart::update($items[$i],['qty' => $quantitys[$i]]);
        }
    	foreach ($removes as $item) {
            Cart::remove($item);
    	}
        return redirect('cart');
    }

    public function account() {
        $id = Auth::user()->id;
        $user = User::findOne($id);
        return view('frontend.pages.account',['user'=>$user]);
    }

    public function editAccount(Request $request) {        
        $id = Auth::user()->id;
        if($request->password === "..........................") {
            User::editNoPass($id,$request->name,$request->email,$request->bank_id,$request->phone,$request->address);
        } else {
            User::edit($id,$request->name,$request->email,$request->password,$request->bank_id,$request->phone,$request->address);
        }
        if (!is_null(Input::file('image'))) {
            File::delete('resources/upload/user/'.$request->currentImage);
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/user/',$fileName);
            User::addImage($id,$fileName);
        }
        return redirect('/account');
    }

    public function checkout() {
        $user = Auth::user();
        return view('frontend.pages.checkout',['user'=>$user]);
    }

    public function getContact() {
        $groups = Nhom::findAll()->get();
        return view ('frontend.pages.contact');
    }

    public function postContact(Request $request) {
        GopY::add($request->name,$request->email,$request->message);
        return "<script> alert('Cửa hàng xin ghi nhận lời góp ý của bạn!'); window.location = '".url('/')."';</script>";
    }

    public function postCheckout(ThanhtoanRequest $request) {
        $content = Cart::content();
        $total = Cart::total();
        $client = new Client();
        $res = $client->post('http://localhost:8080/bank/transfer',array(
                                'headers'=>array('Content-Type'=>'application/json'),
                                'json'=>array(
                                    'id' =>  (int)$request->bank_id,
                                    'pin' => (int)$request->pin,
                                    'ten' => $request->name_user,
                                    'sdt' => $request->phone_user,
                                    'dia_chi' => $request->address_user,
                                    'email' => $request->email_user,
                                    'so_tien' => (int)$total,
                                    'receiver_id' => (int)env('BANK_ID')
                                    )
                                )
                            );
        $result = (string) $res->getBody();
        if($result == 'success') {
            $token = str_random(32);
            User::editNoPass(Auth::user()->id,$request->name_user,$request->email_user,$request->bank_id,$request->phone_user,$request->address_user);

            $order_id = Donhang::add(Auth::user()->id,$request->name,$request->phone,$request->email,$request->address,$request->note,$total,$token);

            foreach ($content as $item) {
                Chitietdonhang::add($item->id,$order_id,$item->qty,$item->price);
            }
            Cart::destroy();

            $hoadon = [
                'id'=> $order_id,
                'nguoi_nhan'=> $request->name,
                'email' => $request->email,
                'sdt' => $request->phone,
                'dia_chi' => $request->address,
                'ghi_chu' => $request->note,
                'tong_tien' => $total,
                'khachhang_id' => Auth::user()->id,
                'token' => $token
                ];
            $email = $request->email_user;
            $name = $request->name_user;
            Mail::send('auth.emails.hoadon', $hoadon, function ($message) use ($email,$name) {
                $message->from(env('MAIL_ADDRESS'), 'ADMIN');
                $message->to($email, $name);
                $message->subject('Hóa đơn mua hàng tại Cửa hàng thể theo Thiên Minh!!!');
            });

            return "<script> alert('Bạn đã đặt mua sản phẩm thành công!'); window.location = '".url('/order')."';</script>";
        } else if($result == 'too_much') {
            return "<script> alert('Quá hạn mức thanh toán!'); window.location = '".url('/cart')."';</script>";
        } else if($result == 'not enough') {
            return "<script> alert('Không đủ tiền trong tài khoản!'); window.location = '".url('/cart')."';</script>";
        } else if($result == 'wrong information') {
        return "<script> alert('Thông tin tài khoản sai!'); window.location = '".url('/checkout')."';</script>";
        }
    }

    public function postComment(BinhluanRequest $request) {
        if(Auth::user()->loai_tai_khoan=='Khách hàng') {
            Binhluan::add(Auth::user()->id,$request->content,$request->product);
        } else {
            Binhluan::addCmtOfEmployee(Auth::user()->id,$request->content,$request->product);
        }
    	return redirect()->back();
    }

    public function getFind(Request $request) {
        $groups = Nhom::findAll()->get();
        $keyword = Input::get("keyword");
        $category = Input::get("category");
        $group = Input::get("group");
        $price = Input::get("price");
        if($price == 0) {
            $price = PHP_INT_MAX;
        }
        $sidebarData = Loaisanpham::findAllWithGroup()->get();
        if($category != '') {
            $products = Sanpham::findAllLikeKeyword($keyword)
            ->where('sanpham.loaisanpham_id','=',$category)
            ->where('sanpham.gia','<=',$price)
            ->paginate(12);
        }
        else if($group != '') {
            $products = Sanpham::findAllLikeKeyword($keyword)
            ->join('loaisanpham','loaisanpham.id', '=', 'sanpham.loaisanpham_id')       
            ->where('loaisanpham.nhom_id','=',$group)
            ->where('sanpham.gia','<=',$price)
            ->paginate(12);
        } else {
            $products = Sanpham::findAllLikeKeyword($keyword)
            ->where('sanpham.gia','<=',$price)
            ->paginate(12);
        }
        $products->appends(['keyword' => $keyword,'group'=>$group,'category'=>$category]);
        return view('frontend.pages.products',['products'=>$products,'sidebarData'=>$sidebarData,'groups'=>$groups]);
    }

    public function postFind(Request $request) {
        $queryString = '/search?keyword='.$request->keyword;
        if($request->group != '')
            $queryString.='&group='.$request->group;
        if($request->category != '')
            $queryString.='&category='.$request->category;
        if($request->price != '') {
            $queryString.='&price='.$request->price;
        }
        return redirect($queryString);
    }

    public function getOrder() {
        $groups = Nhom::findAll()->get();
    	$orders = Donhang::findAllOfCustomer(Auth::user()->id)->get();
    	return view('frontend.pages.order',['orders'=>$orders,'groups'=>$groups]);
    }

    public function getCancelOrder($id) {
		$tong_tien = 0;
        $order = Donhang::findOne($id);
		$orderDetails = Chitietdonhang::findAllByInvoiceID($id)->get();
        if($order->tinh_trang == 'Đang giao hàng') {
            return "<script> alert('Chúng tôi đang giao hàng cho bạn. Xin vui lòng không hủy đơn hàng lúc này!'); window.location = '".url('/order')."';</script>";
        } 
        $tong_tien += $order->tong_tien;
		if( $tong_tien > 0) {
			$user = User::findOne($order->khachhang_id);
			$client =  new Client();
			$res = $client->post('http://localhost:8080/bank/transfer',array(
									'headers'=>array('Content-Type'=>'application/json'),
									'json'=>array(
										'id' => (int)env('BANK_ID'),
										'pin' => (int)env('BANK_PIN'),
										'ten' => env('NAME'),
										'sdt' => env('PHONE_NUMBER'),
										'dia_chi' => env('ADDRESS'),
										'email' => env('MAIL_ADDRESS'),
										'so_tien' => (int)$tong_tien,
										'receiver_id' => (int)$user->so_tai_khoan
										)
									)
								);
			$result = (string) $res->getBody();
			if($result == 'success') {
				Donhang::updateStatus($id,'Hủy');
			} elseif($result == 'too_much') {
				return "<script> alert('Có lỗi xảy ra, đơn hàng chưa thể hủy được!'); window.location = '".url('/order')."';</script>";
			} elseif($result == 'not enough') {
				return "<script> alert('Có lỗi xảy ra, đơn hàng chưa thể hủy được!'); window.location = '".url('/order')."';</script>";
			} elseif($result == 'wrong information') {
				return "<script> alert('Có lỗi xảy ra, đơn hàng chưa thể hủy được!'); window.location = '".url('/order')."';</script>";			
			}
			foreach ($orderDetails as $item) {
				if($item->tinh_trang != 'Hoàn tất') {
                    Lohang::cancel($item->sanpham_id,$item->so_luong);
					Chitietdonhang::updateStatus($item->id,'Hủy');
				}
			}
			Donhang::updateStatus($id,'Hủy');
		}
        $groups = Nhom::findAll()->get();
    	$orders = Donhang::findAllOfCustomer(Auth::user()->id)->get();
    	return view('frontend.pages.order',['orders'=>$orders,'groups'=>$groups]);
    }

    public function getEULA() {
    	return view('frontend.pages.eula');
    }

    public function getVerify($id) {
    	return view('frontend.pages.verify',compact('id'));
    }

    public function postVerify(Request $request) {
        $order = Donhang::findOne($request->id);
        $token = $request->token;

        $createdDate = strtotime(str_replace('/', '-', $order->created_at));
        $diff = abs($createdDate - time()) / 3600;       

        if($diff<24 && $order->token == $token) {
            Donhang::updateStatus($order->id,'Đã xác nhận');
            Donhang::updateToken($order->id,'');
            return "<script> alert('Xác nhận thành công!'); window.location = '".url('/order')."';</script>";
        }
        return "<script> alert('Mã xác nhận sai!'); window.location = '".url('/order')."';</script>";
    }

    public function getOrderDetail($id) {
    	$order = Donhang::findOne($id);
    	$customer = User::findOne($order->khachhang_id);
    	$orderDetails = Chitietdonhang::findAllByInvoiceIDWithProduct($order->id)->get();
        if($order->tinh_trang == 'Hoàn tất')
            return view('frontend.pages.order-detail',['order'=>$order,'customer'=>$customer,'orderDetails'=>$orderDetails]);
		return view('frontend.pages.order-edit',['order'=>$order,'customer'=>$customer,'orderDetails'=>$orderDetails]);
    }

    public function postOrder(Request $request) {
    	Donhang::edit($id,$request->name,$request->phone,$request->email,$request->address,$request->note);
        return "<script> alert('Chỉnh sửa thành công!!!'); window.location = '".url('/order')."';</script>";
    }

}
