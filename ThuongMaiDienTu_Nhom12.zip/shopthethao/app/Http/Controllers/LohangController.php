<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// use App\Http\Requests;
use App\Http\Requests\LohangAddRequest;
use App\Http\Requests\LohangEditRequest;
use App\Lohang;
use App\Sanpham;
use App\Nhacungcap;
use DB;
use Input,File;

class LohangController extends Controller
{
    public function getList() {
    	$loHangs = Lohang::findAll()->get();
    	return view('backend.lohang.danhsach',['loHangs'=>$loHangs]);
    }

    public function getAdd() {
        $products = Sanpham::findAll()
                    ->where(DB::raw('sanpham.user_id'))
                    ->get();
    	return view('backend.lohang.them',['products'=>$products]);
    }

    public function getAddByPartner() {
        $products = Sanpham::findAll()->where(DB::raw('NOT sanpham.user_id'))->get();
    	return view('backend.doitac.them',['products'=>$products]);
    }

    public function postAdd(Request $request) {
        $lohang = Lohang::findOneByProduct($request->productID);
        if(is_null($lohang)) {
            Lohang::add($request->quantity,$request->productID);
        } else {
            Lohang::edit($lohang->id,$request->quantity,$request->productID);
        }
		session()->flash('flash_level','success');
		session()->flash('flash_message','Nhập hàng thành công!!!');
        return redirect('dashboard/lohang');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm lô hàng thành công!!!']);
    }

    public function getEdit($id) {
        $lohang = Lohang::findOne($id);
        $product = Sanpham::findOne($lohang->sanpham_id);
    	return view('backend.lohang.sua',['product'=>$product,'lohang'=>$lohang]);
    }

    public function postEdit(Request $request, $id) {
        Lohang::edit($id,$request->quantity,$request->product);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Cập nhật thông tin kho hàng thành công!!!');
    	return redirect('dashboard/lohang');
        // ->with(['flash_level'=>'success','flash_message'=>'Cập nhật lô hàng thành công!!!']);
    }

    public function getDelete($id) {
    	Lohang::remove($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa thành công!!!');
        return redirect('dashboard/lohang');
        // ->with(['flash_level'=>'success','flash_message'=>'Xóa thành công!!!']);
    }

    public function getNhaphang($id) {
        $product = Sanpham::findOne($id);
        return view('backend.lohang.nhaphang',['product'=>$product]);
    }
}
 