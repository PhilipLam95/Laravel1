<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

//use App\Http\Requests;

use App\Http\Requests\LoaisanphamAddRequest;
use App\Http\Requests\LoaisanphamEditRequest;

use App\Loaisanpham;
use App\Nhom;
use DB;

use Input,File;

class LoaisanphamController extends Controller {
	public function findAllInGroup($id) {
        $nhoms = Loaisanpham::findAllInGroup($id)->paginate(12);
    	return $nhoms;
    }

    public function getList() {
		$categories = Loaisanpham::findAllWithGroup()->get();
		return view('backend.loaisanpham.danhsach',['categories'=>$categories]);
	}

	public function getAdd() {
		$groups = Nhom::findAll()->get();
		return view('backend.loaisanpham.them',['groups'=>$groups]);
	}

	public function postAdd(LoaisanphamAddRequest $request) {
		Loaisanpham::add($request->name,$request->group);		
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm thành công!!!');
		return redirect('dashboard/category');
	}

	public function remove($id) {
		Loaisanpham::remove($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa thành công!!!');
        return redirect('dashboard/category');
	}

	public function getEdit($id) {
		$category = Loaisanpham::findOne($id);
		$groups = Nhom::findAll()->get();
		return view('backend.loaisanpham.sua',['category'=>$category,'groups'=>$groups]);
	}

	public function postEdit(LoaisanphamEditRequest $request,$id)
	{
        Loaisanpham::edit($id,$request->name,$request->group);		
		session()->flash('flash_level','success');
		session()->flash('flash_message','Chỉnh sửa thành công!!!');
		return redirect('dashboard/category');
	}
}
