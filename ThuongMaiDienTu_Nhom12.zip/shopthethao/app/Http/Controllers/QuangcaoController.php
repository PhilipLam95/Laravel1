<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\QuangcaoAddRequest;
use App\Http\Requests\QuangcaoEditRequest;
use App\Quangcao;
use App\Sanpham;
use DB;
use File;
use Illuminate\Support\Facades\Input;

class QuangcaoController extends Controller
{
    public function getList() {
        $acceptedAdvertisements = Quangcao::findAllAccepted()->orderBy('id','DESC')->get();
        $unacceptedAdvertisements = Quangcao::findAllUnaccepted()->orderBy('id','DESC')->get();
        $advertisements = collect($acceptedAdvertisements)->merge(collect($unacceptedAdvertisements))->sortByDesc('id');
    	return view('backend.quangcao.danhsach',['advertisements'=>$advertisements,'acceptedAdvertisements'=>$acceptedAdvertisements,'unacceptedAdvertisements'=>$unacceptedAdvertisements]);
    }

    public function getAdd() {
        $products = Sanpham::findAll()->get();
    	return view('backend.quangcao.them',['products'=>$products]);
    }

    public function postAdd(QuangcaoAddRequest $request) {
        $id = Quangcao::add($request->name,$request->status,$request->product,$request->description);
        if (Input::file('image')->isValid()) {
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/quangcao/',$fileName);
            Quangcao::addImage($id,$fileName);
        }
		session()->flash('flash_level','success');
		session()->flash('flash_message','Thêm thành công!!!');
    	return redirect('dashboard/advertisement');
        // ->with(['flash_level'=>'success','flash_message'=>'Thêm thành công!!!']);
    }

    public function getEdit($id) {
    	$advertisement = Quangcao::findOne($id);
    	return view('backend.quangcao.sua',['advertisement'=>$advertisement]);
    }

    public function postEdit(QuangcaoEditRequest $request, $id) {
        Quangcao::edit($id,$request->name,$request->status,$request->description);
        if (!is_null(Input::file('image')) && Input::file('image')->isValid()) {
            File::delete('resources/upload/sanpham/'.$request->currentImage);
            $extension = Input::file('image')->getClientOriginalExtension();
            $fileName = $id.'.'.$extension;
            Input::file('image')->move(base_path().'/resources/upload/quangcao/',$fileName);
            Quangcao::addImage($id,$fileName);
        }
		session()->flash('flash_level','success');
		session()->flash('flash_message','Cập nhật thành công!!!');
    	return redirect('dashboard/advertisement');
        // ->with(['flash_level'=>'success','flash_message'=>'Cập nhật thành công!!!']);
    }

    public function hide($id) {
        Quangcao::hide($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Đã ẩn quảng cáo!!!');
    	return redirect('dashboard/advertisement');
        // ->with(['flash_level'=>'success','flash_message'=>'Cập nhật thành công!!!']);
    }

    public function show($id) {
        Quangcao::show($id);
		session()->flash('flash_level','success');
		session()->flash('flash_message','Đã hiện quảng cáo!!!');
    	return redirect('dashboard/advertisement');
        // ->with(['flash_level'=>'success','flash_message'=>'Cập nhật thành công!!!']);
    }

    public function getDelete($id) {
        $quangcao = DB::table('quangcao')->where('id',$id)->first();
        $img = 'resources/upload/quangcao/'.$quangcao->anh;
        File::delete($img);
		DB::table('quangcao')->where('id',$id)->delete();
		session()->flash('flash_level','success');
		session()->flash('flash_message','Xóa thành công!!!');
        return redirect('dashboard/advertisement');
        // ->with(['flash_level'=>'success','flash_message'=>'Xóa thành công!!!']);
	}
}
