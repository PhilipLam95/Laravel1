<?php

namespace App\Http\Middleware;

use Closure;

class MobileAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = \App\User::findOneByEmail($request->email);
        if (is_null($user) || bcrypt($request->password) != $user->password)  {
            return response('Unauthorized.', 401);
        }
        
        return $next($request);
    }
}
