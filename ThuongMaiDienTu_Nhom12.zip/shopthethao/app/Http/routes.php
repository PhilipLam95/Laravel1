<?php

// Route::get('/', function () {
//     return view('frontend.master');
// });

Route::controllers([
 'auth' => 'Auth\AuthController',
 'password' => 'Auth\PasswordController',
]);

// Authentication Routes...
Route::get('login', 'Auth\AuthController@showLoginForm');
Route::post('login', 'Auth\AuthController@postLogin');
Route::get('logout', 'Auth\AuthController@logout');

// Registration Routes...
Route::get('register', 'Auth\AuthController@showRegistrationForm');
Route::post('register', 'Auth\AuthController@register');
Route::post('user-verify','Auth\AuthController@postVerify');

// Password Reset Routes...
Route::get('password/reset/{token?}', 'Auth\PasswordController@showResetForm');
Route::post('password/email', 'Auth\PasswordController@sendResetLinkEmail');
Route::post('password/reset', 'Auth\PasswordController@reset');

Route::group(['middleware' => 'customer'], function() {

    Route::get('/', 'HomeController@index');

    Route::get('products', 'HomeController@products');
    Route::get('promotions', 'HomeController@promotions');
    Route::get('groups', 'HomeController@getGroupList');
    Route::get('group/{id}', 'HomeController@getGroup');

    Route::get('category/{id}', 'HomeController@getCategory');

    Route::get('product-details/{id}', 'HomeController@productDetails');

    Route::get('contact', 'HomeController@getContact');
    Route::post('contact', 'HomeController@postContact');

    Route::get('getBuy/{id}','HomeController@getBuy');
    Route::post('postBuy','HomeController@postBuy');

    Route::get('cart','HomeController@cart');
    Route::post('cart','HomeController@updateCart');

    Route::get('account',['middleware'=>'auth','uses'=>'HomeController@account']);
    Route::post('account',['middleware'=>'auth','uses'=>'HomeController@editAccount']);

    Route::get('checkout','HomeController@checkout');
    Route::post('checkout',['middleware'=>'auth','uses'=>'HomeController@postCheckout']);

    Route::post('comment',['middleware'=>'auth','uses'=>'HomeController@postComment']);

    Route::get('order',['middleware'=>'auth','uses'=>'HomeController@getOrder']);
    Route::get('cancel-order/{id}',['middleware'=>'auth','uses'=>'HomeController@getCancelOrder']);
    Route::get('order/{id}',['middleware'=>'auth','uses'=>'HomeController@getOrderDetail']);
    Route::post('order',['middleware'=>'auth','uses'=>'HomeController@postOrder']);

    Route::get('search','HomeController@getFind');
    Route::post('search','HomeController@PostFind');

    Route::get('eula','HomeController@getEULA');

    Route::get('verify/{id}',['middleware'=>'auth','uses'=>'HomeController@getVerify']);
    Route::post('verify',['middleware'=>'auth','uses'=>'HomeController@postVerify']);
});

// Route mobile
Route::group(['prefix' => 'mobile', 'middleware' => ['throttle', 'cors']], function() {
    Route::post('signup', 'MobileController@signup');
    Route::get('groups', 'HomeController@getGroupList');
    Route::get('group/{id}', 'HomeController@getGroup');
    Route::get('products', 'MobileController@findAllWithPromotionToMobile');
    Route::get('promotions', 'MobileController@findAllPromotionsWithProduct');
    Route::get('product/{id}', 'MobileController@findOneWithPromotionToMobile');
    Route::get('product/{id}/comment', 'MobileController@findAllCommentsOfProduct');
    Route::post('checkout',['middleware'=>'jwt.auth','uses'=>'MobileController@checkout']);
    Route::post('comment',['middleware'=>'jwt.auth','uses'=>'MobileController@comment']);
    Route::get('find','MobileController@getFind');
    Route::get('order',['middleware'=>'jwt.auth','uses'=>'MobileController@getOrder']);
    Route::post('login','MobileController@login');
});

// Route Backend
Route::group(['prefix' => 'partner','middleware' => 'partner'], function() {
        Route::get('home','SanphamController@getListByPartner');
        Route::get('add','SanphamController@getAddByPartner');
        Route::post('add','SanphamController@postAddByPartner');
        Route::get('remove/{id}','SanphamController@removeByPartner');
        Route::get('edit/{id}','SanphamController@getEditByPartner');
        Route::post('edit/{id}','SanphamController@postEditByPartner');
        Route::get('promotion/add','KhuyenmaiController@getAddByPartner');
        Route::post('promotion/add','KhuyenmaiController@postAddByPartner');
        Route::get('promotion/remove/{id}','KhuyenmaiController@getDeleteByPartner');
        Route::get('promotion/{id}','KhuyenmaiController@getEditByPartner');
        Route::post('promotion/{id}','KhuyenmaiController@postEditByPartner');
        Route::get('order/{id}', 'DonhangController@getOrderDetailForPartner');
});

Route::group(['prefix' => 'dashboard','middleware' => 'employee'], function() {
    Route::get('home', 'AdminController@index');

    Route::get('category', 'LoaisanphamController@getList');
    Route::get('group', 'NhomController@getList');
    Route::get('lohang', 'LohangController@getList');
    Route::get('lohang/nhap-hang/{id}', 'LohangController@getNhaphang');
    Route::get('vendor', 'NhacungcapController@getList');

    Route::get('customer', 'UserController@getCustomer');
    Route::get('customer/{id}/history','UserController@getHistory');
    Route::get('customer/add', 'UserController@getAddCustomer');
    Route::post('customer/add', 'UserController@postAddCustomer');

    Route::get('partner', 'UserController@getPartner');
    Route::get('partner/add', 'UserController@getAddPartner');
    Route::post('partner/add', 'UserController@postAddPartner');

    Route::get('product','SanphamController@getList');
    Route::get('promotion','KhuyenmaiController@getList');

    Route::get('comment','BinhluanController@getList');
    Route::get('comment/{id}/remove', 'BinhluanController@remove');
    Route::get('comment/{id}/approve','BinhluanController@acceptComments');
    Route::get('comment/{id}/unapprove','BinhluanController@unacceptComments');

    Route::get('gopy/{id}/remove', 'BinhluanController@removeGopy');

    Route::get('order', 'DonhangController@getList');
    Route::get('order/{id}', 'DonhangController@getEdit');
    Route::post('order/{id}', 'DonhangController@postEdit');
    Route::get('order/{id}/pdf', 'DonhangController@pdf');
    Route::get('order/{id}/verify', 'DonhangController@verify');
    Route::get('order/{id}/cancel', 'DonhangController@cancel');
    Route::get('order/{id}/process', 'DonhangController@process');
    Route::get('order/{id}/finish', 'DonhangController@finish');
    Route::get('order/{id}/delivery', 'DonhangController@deliveryOrder');

    Route::get('advertisement', 'QuangcaoController@getList');
    Route::get('advertisement/add', 'QuangcaoController@getAdd');
    Route::post('advertisement/add', 'QuangcaoController@postAdd');
    Route::get('advertisement/{id}/remove', 'QuangcaoController@getDelete');
    Route::get('advertisement/{id}', 'QuangcaoController@getEdit');
    Route::post('advertisement/{id}', 'QuangcaoController@postEdit');
    Route::get('advertisement/{id}/show', 'QuangcaoController@show');
    Route::get('advertisement/{id}/hide', 'QuangcaoController@hide');

    Route::group(['middleware' => 'admin'], function() {
        Route::get('category/add', 'LoaisanphamController@getAdd');
        Route::post('category/add', 'LoaisanphamController@postAdd');
        Route::get('category/{id}','LoaisanphamController@getEdit');
        Route::post('category/{id}', 'LoaisanphamController@postEdit');
        Route::get('category/{id}/remove','LoaisanphamController@remove');

        Route::get('group/add', 'NhomController@getAdd');
        Route::post('group/add', 'NhomController@postAdd');
        Route::get('group/{id}/remove','NhomController@remove');
        Route::get('group/{id}','NhomController@getEdit');
        Route::post('group/{id}','NhomController@postEdit');

        Route::get('lohang/add', 'LohangController@getAdd');
        Route::get('lohang/add-partner', 'LohangController@getAddByPartner');
        Route::post('lohang/add', 'LohangController@postAdd');
        Route::get('lohang/{id}/remove', 'LohangController@getDelete');
        Route::get('lohang/{id}', 'LohangController@getEdit');
        Route::post('lohang/{id}', 'LohangController@postEdit');

        Route::get('customer/{id}/remove', 'UserController@remove');
        Route::get('customer/{id}/ban', 'UserController@ban');
        Route::get('customer/{id}/unban', 'UserController@ban');
        Route::get('customer/{id}/verify', 'UserController@verify');
        Route::get('customer/{id}/upgrade', 'UserController@upgrade');

        Route::get('employee', 'UserController@getEmployee');
        Route::get('employee/add', 'UserController@getAddEmployee');
        Route::post('employee/add', 'UserController@postAddEmployee');
        Route::get('employee/{id}/remove', 'UserController@remove');
        Route::get('employee/{id}/ban', 'UserController@ban');
        Route::get('employee/{id}/unban', 'UserController@ban');

        Route::get('partner/{id}/downgrade', 'UserController@downgrade');
        Route::get('partner/{id}/ban', 'UserController@ban');
        Route::get('partner/{id}/unban', 'UserController@ban');

        Route::get('product/add','SanphamController@getAdd');
        Route::post('product/add','SanphamController@postAdd');
        Route::get('product/{id}/remove','SanphamController@remove');
        Route::get('product/{id}','SanphamController@getEdit');
        Route::post('product/{id}','SanphamController@postEdit');

        Route::get('promotion/add', 'KhuyenmaiController@getAdd');
        Route::post('promotion/add', 'KhuyenmaiController@postAdd');
        Route::get('promotion/{id}/remove', 'KhuyenmaiController@getDelete');
        Route::get('promotion/{id}', 'KhuyenmaiController@getEdit');
        Route::post('promotion/{id}', 'KhuyenmaiController@postEdit');

        Route::get('thongke', 'ThongkeController@getList');
        Route::get('thongke/import', 'ThongkeController@getImport');
        Route::get('thongke/sale', 'ThongkeController@getSale');
        Route::get('thongke/available', 'ThongkeController@getAvailable');
        Route::get('thongke/return', 'ThongkeController@getReturn');
        Route::get('thongke/hot-sale', 'ThongkeController@getHotSale');
        Route::get('thongke/instock', 'ThongkeController@getInactiveStock');
    });
});
