<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class NhacungcapAddRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'     => 'required|unique:nhacungcap,ten',
            'phone'    => 'required|max:12|min:10',
            'address'   => 'required'
        ];
    }
    public function messages() {
        return [
            'required'   => 'Vui lòng không để trống trường này!',
            'name.unique'     => 'Nhóm thực phẩm này đã tồn tại!',
            'phone.max'   => 'Số điện thoại vượt quá độ dài cho phép!',
            'phone.min'   => 'Số điện thoại ngắn hơns độ dài cho phép!'
        ];
    }
}
