<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class SanphamEditRequest extends Request
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'  => 'required',
            'category'  => 'required',
            'description' => 'required',
            'price' => 'required',
            'image' => 'mimes:jpeg,bmp,png|max:4000',
        ];
    }

    public function messages() {
        return [
            'required'   => 'Vui lòng không để trống trường này!',
            'mimes' => 'Vui lòng chọn đúng file ảnh',
            'max' => 'Vui lòng chọn file ảnh có kích thước không quá 4MB'
        ];
    }
}
