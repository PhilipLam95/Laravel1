<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class QuangcaoAddRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'    => 'required',
            'image' => 'required|mimes:jpeg,bmp,png|max:4000'
        ];
    }

    public function messages() {
        return [
            'name.required'   => 'Vui lòng không để trống trường này!',
            'mimes' => 'Vui lòng chọn đúng file ảnh',
            'image.max' => 'Vui lòng chọn file ảnh có kích thước không quá 4MB'
        ];
    }
}
