<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class RegisterRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'   =>'required',
            '_email'  =>'required|unique:users,email|regex:^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})^',
            '_password'   =>'required',
            'password_confirmation' =>'required|same:password',
            'phone'   =>'required',
            'address'   =>'required',
            'bank_id'   =>'required',
             'image' => 'required|mimes:jpeg,bmp,png|max:4000'
        ];
    }

    public function messages()
    {
        return [
            'required'=> 'Vui lòng không để trống trường này!',
            '_email.unique'  =>'Email này đã được sử dụng!',
            '_email.regex'  =>'Email không đúng định dạng!',
            'password_confirmation.same' =>'Mật khẩu không trùng khớp!',
            'mimes' => 'Vui lòng chọn đúng file ảnh',
            'image.max' => 'Vui lòng chọn file ảnh có kích thước không quá 4MB'
        ];
    }
}
