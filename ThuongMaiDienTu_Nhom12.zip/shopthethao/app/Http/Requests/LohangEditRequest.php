<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class LohangEditRequest extends Request
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'quantity'  => 'required|integer',
            'importPrice'  => 'required',
        ];
    }

    public function messages() {
        return [
            'required'   => 'Vui lòng không để trống trường này!',
            'integer'   => 'Kiểu dữ liệu không phù hợp!'
        ];
    }
}
