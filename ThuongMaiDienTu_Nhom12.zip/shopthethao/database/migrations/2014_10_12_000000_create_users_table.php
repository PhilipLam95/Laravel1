<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('email',100)->unique();
			$table->string('password', 200);
			$table->string('ten',100);
            $table->string('so_tai_khoan');
            $table->string('sdt', 12);
            $table->string('dia_chi', 200);
			$table->string('loai_tai_khoan',20);
			$table->string('anh');
			$table->string('verifytoken');
			$table->string('trang_thai');
			$table->rememberToken();
			$table->timestamps();
		});
		App\User::create([
            'ten' => 'admin',
            'email' => 'admin@admin.com',
            'password' => bcrypt('123'),
            'loai_tai_khoan' => 'Admin',
        ]);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
