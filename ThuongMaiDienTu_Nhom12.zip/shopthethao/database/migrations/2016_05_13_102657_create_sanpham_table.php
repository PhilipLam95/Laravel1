<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSanphamTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sanpham', function(Blueprint $table)
        {
            $table->increments('id');
            $table->string('ten');
            $table->string('anh_0');
            $table->decimal('gia',10,2);
            $table->longText('mo_ta');
            $table->integer('luot_xem');
            $table->integer('loaisanpham_id')->unsigned();
            $table->foreign('loaisanpham_id')->references('id')->on('loaisanpham')->onUpdate('cascade');
            $table->integer('user_id')->unsigned()->nullable();
            $table->timestamps();
        });
        Schema::table('sanpham', function ($table) {
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('sanpham');
    }
}
