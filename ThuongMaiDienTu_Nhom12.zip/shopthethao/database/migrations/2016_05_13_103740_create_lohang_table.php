<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLohangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lohang', function (Blueprint $table) {
            $table->increments('id');
            // $table->decimal('gia_mua_vao',10,2);
            $table->integer('so_luong_nhap');
            $table->integer('so_luong_da_ban');
            $table->integer('so_luong_giao_hang');
            $table->integer('so_luong_doi_tra');
            $table->integer('so_luong_hien_tai');
            $table->integer('sanpham_id')->unsigned();
            $table->foreign('sanpham_id')->references('id')->on('sanpham')->onUpdate('cascade');
            $table->integer('nhacungcap_id')->unsigned();
            $table->foreign('nhacungcap_id')->references('id')->on('nhacungcap')->onUpdate('cascade');
            $table->integer('tinh_trang');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('lohang');
    }
}

