<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDonhangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('donhang', function (Blueprint $table) {
            $table->increments('id');
            $table->string('nguoi_nhan',100);
            $table->string('email');
            $table->string('sdt', 12);
            $table->string('dia_chi', 200);
            $table->longText('ghi_chu');
            $table->decimal('tong_tien',10,2);
            $table->integer('khachhang_id')->unsigned();
            $table->foreign('khachhang_id')->references('id')->on('users')->onUpdate('cascade');
            $table->string('token',48);
            $table->string('tinh_trang');
            $table->datetime('delivered_at');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('donhang');
    }
}
