<?php

use Illuminate\Database\Seeder;

class NhomTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('nhom')->insert([
            'ten' => 'Thịt',
        ]);
        DB::table('nhom')->insert([
            'ten' => 'Rau',
        ]);
        DB::table('nhom')->insert([
            'ten' => 'Hoa quả',
        ]);
        DB::table('nhom')->insert([
            'ten' => 'Thực phẩm khô',
        ]);
    }
}
